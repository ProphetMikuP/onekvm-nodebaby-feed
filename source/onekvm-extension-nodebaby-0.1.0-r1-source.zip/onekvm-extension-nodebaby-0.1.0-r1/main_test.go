// SPDX-License-Identifier: MIT
package main

import (
	"bytes"
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"syscall"
	"testing"
	"time"
)

func fixture(t *testing.T) Layout {
	t.Helper()
	base := t.TempDir()
	l := Layout{filepath.Join(base, "package"), filepath.Join(base, "data"), filepath.Join(base, "config.json")}
	os.MkdirAll(l.Root, 0700)
	os.MkdirAll(l.Data, 0700)
	// A stubborn foreground process plus a setsid child. Neither responds to TERM.
	fake := []byte("#!/bin/sh\ntrap '' TERM\nsetsid /bin/sh -c 'trap \"\" TERM; sleep 90 & wait' &\nwait\n")
	files := []FileSpec{}
	for _, name := range []string{"bin/owjdxb", "ownbsv/ownbsvman", "ownbsv/NodeBabyLinkService", "owjdgj/owjdgjman"} {
		target := filepath.Join(l.Root, "runtime/owjdxb", name)
		os.MkdirAll(filepath.Dir(target), 0700)
		os.WriteFile(target, fake, 0700)
		sum := sha256.Sum256(fake)
		files = append(files, FileSpec{name, hex.EncodeToString(sum[:]), true})
	}
	b, _ := json.Marshal(files)
	os.WriteFile(filepath.Join(l.Root, "runtime-index.json"), b, 0600)
	listener, e := net.Listen("tcp", "127.0.0.1:0")
	if e != nil {
		t.Fatal(e)
	}
	port := listener.Addr().(*net.TCPAddr).Port
	listener.Close()
	b, _ = json.Marshal(Settings{true, port})
	os.WriteFile(l.Config, b, 0600)
	return l
}
func TestBindingURL(t *testing.T) {
	for _, s := range []string{"https://www.iepose.com/istore/?sn=abc", "https://ionewu.com/istore/?x=1"} {
		if _, e := bindingURL(s); e != nil {
			t.Fatal(s, e)
		}
	}
	for _, s := range []string{"javascript:alert(1)", "http://iepose.com/istore/", "https://iepose.com.evil.invalid/istore/", "https://iepose.com@evil.invalid/istore/", "https://iepose.com:443/istore/", "https://iepose.com/other", "https://evil.invalid/istore/"} {
		if _, e := bindingURL(s); e == nil {
			t.Fatal("accepted", s)
		}
	}
}
func TestPayloadTamperAndSymlink(t *testing.T) {
	l := fixture(t)
	if e := verifyPayload(l); e != nil {
		t.Fatal(e)
	}
	runtime, e := materialize(l)
	if e != nil {
		t.Fatal(e)
	}
	os.WriteFile(filepath.Join(runtime, "bin/owjdxb"), []byte("tampered"), 0700)
	if _, e = materialize(l); e != nil {
		t.Fatal(e)
	}
	if bytes.Equal(mustRead(t, filepath.Join(runtime, "bin/owjdxb")), []byte("tampered")) {
		t.Fatal("working binary not restored")
	}
	target := filepath.Join(l.Root, "runtime/owjdxb/bin/owjdxb")
	os.WriteFile(target, []byte("tampered"), 0700)
	if e = verifyPayload(l); e == nil {
		t.Fatal("tampered package accepted")
	}
	os.Remove(target)
	os.Symlink("/bin/sh", target)
	if e = verifyPayload(l); e == nil {
		t.Fatal("symlink accepted")
	}
}
func mustRead(t *testing.T, p string) []byte {
	t.Helper()
	b, e := os.ReadFile(p)
	if e != nil {
		t.Fatal(e)
	}
	return b
}
func TestSettingsAndStaleState(t *testing.T) {
	l := fixture(t)
	for _, s := range []string{`{"port":22}`, `{"port":65536}`, `{"port":"9118"}`, `{"port":9118,"service_enabled":"true"}`, `invalid`} {
		os.WriteFile(l.Config, []byte(s), 0600)
		if _, e := loadSettings(l.Config); e == nil {
			t.Fatal("accepted", s)
		}
	}
	self, _ := proc(os.Getpid())
	if stateLive(State{BootID: "old-boot", Controller: self, Client: self}) {
		t.Fatal("stale boot state accepted")
	}
	if e := bindingURLTestHelper(l); e == nil {
		t.Fatal("binding should fail with no owned listener")
	}
}
func bindingURLTestHelper(l Layout) error { _, e := binding(l); return e }
func TestScopedSignalLeavesSibling(t *testing.T) {
	child := exec.Command("sleep", "30")
	if e := child.Start(); e != nil {
		t.Fatal(e)
	}
	defer func() { child.Process.Kill(); child.Wait() }()
	p, _ := proc(child.Process.Pid)
	// Parent=unrelated PID must never signal this process.
	if e := signalOwned(p, 999999, syscall.SIGTERM); e != nil && e != syscall.ESRCH {
		t.Fatal(e)
	}
	if !sameProc(p) {
		t.Fatal("unowned process stopped")
	}
	p.Start = "different-start-time"
	if e := signalOwned(p, os.Getpid(), syscall.SIGTERM); e != nil {
		t.Fatal(e)
	}
	if e := child.Process.Signal(syscall.Signal(0)); e != nil {
		t.Fatal("stale PID record stopped a process", e)
	}
}
func TestCappedLog(t *testing.T) {
	f, e := os.CreateTemp(t.TempDir(), "log")
	if e != nil {
		t.Fatal(e)
	}
	defer f.Close()
	w := &cappedLog{file: f}
	for i := 0; i < 8; i++ {
		if _, e = w.Write(bytes.Repeat([]byte("x"), 400000)); e != nil {
			t.Fatal(e)
		}
	}
	st, _ := f.Stat()
	if st.Size() > 1<<20 {
		t.Fatal("unbounded log")
	}
}
func TestServiceHelper(t *testing.T) {
	if os.Getenv("NB_SERVICE_TEST") != "1" {
		return
	}
	var l Layout
	if e := json.Unmarshal([]byte(os.Getenv("NB_LAYOUT")), &l); e != nil {
		t.Fatal(e)
	}
	ctx, cancel := context.WithCancel(context.Background())
	defer cancel()
	// Test cancellation uses a file so no signal handling or test-runner flags
	// leak into the vendor substitute.
	go func() {
		for {
			if _, e := os.Stat(filepath.Join(l.Data, "cancel")); e == nil {
				cancel()
				return
			}
			time.Sleep(25 * time.Millisecond)
		}
	}()
	if e := service(ctx, l); e != nil {
		t.Fatal(e)
	}
}
func TestLifecycleStopsDaemonizedDescendants(t *testing.T) {
	l := fixture(t)
	b, _ := json.Marshal(l)
	exe, _ := os.Executable()
	helper := exec.Command(exe, "-test.run=^TestServiceHelper$", "-test.v")
	helper.Env = append(os.Environ(), "NB_SERVICE_TEST=1", "NB_LAYOUT="+string(b))
	var output bytes.Buffer
	helper.Stdout = &output
	helper.Stderr = &output
	if e := helper.Start(); e != nil {
		t.Fatal(e)
	}
	defer func() { helper.Process.Kill() }()
	// A sibling process is deliberately outside the wrapper's ancestry.
	sibling := exec.Command("sleep", "30")
	sibling.Start()
	defer func() { sibling.Process.Kill(); sibling.Wait() }()
	deadline := time.Now().Add(10 * time.Second)
	var state State
	for {
		state, _ = loadState(l)
		if stateLive(state) && len(descendants(helper.Process.Pid)) >= 3 {
			break
		}
		if time.Now().After(deadline) {
			t.Fatal("startup timeout", output.String())
		}
		time.Sleep(25 * time.Millisecond)
	}
	owned := descendants(helper.Process.Pid)
	os.WriteFile(filepath.Join(l.Data, "cancel"), []byte("stop"), 0600)
	done := make(chan error, 1)
	go func() { done <- helper.Wait() }()
	select {
	case e := <-done:
		if e != nil {
			t.Fatal(e, output.String())
		}
	case <-time.After(8 * time.Second):
		t.Fatal("stop timeout")
	}
	if e := sibling.Process.Signal(syscall.Signal(0)); e != nil {
		t.Fatal("sibling killed", e)
	}
	for _, p := range owned {
		if sameProc(p) {
			t.Errorf("orphan remained: %+v", p)
		}
	}
	if _, e := os.Stat(filepath.Join(l.Data, "state.json")); !os.IsNotExist(e) {
		t.Fatal("stale state retained")
	}
	if !strings.Contains(string(mustRead(t, filepath.Join(l.Data, "last-event.json"))), "停止") {
		t.Fatal("missing stop event")
	}
	fmt.Fprintln(os.Stdout, "Verified TERM-to-KILL escalation and setsid descendant cleanup; sibling preserved.")
}
