#!/usr/bin/env python3
"""Verify signatures and package hashes using only the bundled public key.
Negative tests use copied temporary data, leaving the signed feed unchanged.
"""
import argparse,gzip,hashlib,json,os,subprocess,tempfile
from pathlib import Path
from verify_ipk import verify

def verify_feed(feed):
 public=(feed/'nodebaby-feed-public.asc').read_bytes()
 if b'PRIVATE KEY' in public:raise ValueError('private signing material in public feed')
 fpr=(feed/'FINGERPRINT.txt').read_text().strip()
 for p in feed.iterdir():
  if any(s in p.name.lower() for s in ['secret','passphrase','revocation','private']):raise ValueError('private material filename')
 with tempfile.TemporaryDirectory(prefix='nodebaby-verifier-') as home:
  os.chmod(home,0o700);base=['gpg','--no-options','--homedir',home,'--batch','--no-auto-key-retrieve']
  subprocess.run(base+['--import',str((feed/'nodebaby-feed-public.asc').resolve())],check=True,capture_output=True)
  check=subprocess.run(base+['--status-fd','1','--verify',str((feed/'Packages.asc').resolve()),str((feed/'Packages').resolve())],capture_output=True,text=True)
  if check.returncode or not any(line.startswith('[GNUPG:] VALIDSIG '+fpr+' ') for line in check.stdout.splitlines()):raise ValueError('index signature invalid or wrong signer')
  subprocess.run(base+['--verify',str((feed/'Packages.sig').resolve()),str((feed/'Packages').resolve())],check=True,capture_output=True)
  index=(feed/'Packages').read_bytes()
  if gzip.decompress((feed/'Packages.gz').read_bytes())!=index:raise ValueError('gzip index differs from signed index')
  fields=dict(line.split(': ',1) for line in index.decode().splitlines() if line)
  filename=fields['Filename'];p=Path(filename)
  if p.name!=filename or not filename.endswith('.ipk'):raise ValueError('unsafe package filename')
  ipk=feed/filename;data=ipk.read_bytes()
  if len(data)!=int(fields['Size']) or hashlib.sha256(data).hexdigest()!=fields['SHA256sum']:raise ValueError('package integrity failed')
  verify(ipk)
  subprocess.run(base+['--verify',str((feed/(filename+'.asc')).resolve()),str(ipk.resolve())],check=True,capture_output=True)
  tampered=Path(home)/'tampered-Packages';tampered.write_bytes(index+b'# altered\n')
  bad=subprocess.run(base+['--verify',str((feed/'Packages.asc').resolve()),str(tampered)],capture_output=True)
  if bad.returncode==0:raise ValueError('tampered index accepted')
  altered=data[:-1]+bytes([data[-1]^1])
  if hashlib.sha256(altered).hexdigest()==fields['SHA256sum']:raise ValueError('tampered package accepted')
  tampered_ipk=Path(home)/'tampered.ipk';tampered_ipk.write_bytes(altered)
  if subprocess.run(base+['--verify',str((feed/(filename+'.asc')).resolve()),str(tampered_ipk)],capture_output=True).returncode==0:raise ValueError('tampered package signature accepted')
  # Verify that a completely empty keyring rejects the signature.
  with tempfile.TemporaryDirectory(prefix='nodebaby-untrusted-') as empty:
   os.chmod(empty,0o700)
   unknown=subprocess.run(['gpg','--no-options','--homedir',empty,'--batch','--no-auto-key-retrieve','--verify',str((feed/'Packages.asc').resolve()),str((feed/'Packages').resolve())],capture_output=True)
   if unknown.returncode==0:raise ValueError('signature accepted without trusted key')
  return {'passed':True,'fingerprint':fpr,'index_signature_valid':True,'gzip_matches_signed_index':True,'package_hash_valid':True,'package_signature_valid':True,'tampered_index_rejected':True,'tampered_package_detected':True,'missing_key_rejected':True,'private_material_absent':True,'device_tested':False,'published':False}

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('feed',type=Path);a=p.parse_args();print(json.dumps(verify_feed(a.feed),indent=2))
