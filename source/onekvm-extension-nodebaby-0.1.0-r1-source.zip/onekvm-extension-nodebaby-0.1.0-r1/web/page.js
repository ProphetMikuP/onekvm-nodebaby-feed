// SPDX-License-Identifier: MIT
(() => {
  const runtime = window.OneKVMPluginUI.v1
  const { defineComponent, h, ref, computed, onMounted, onBeforeUnmount } = runtime.vue
  const { NAlert, NButton, NInputNumber, NSwitch, NTag, NModal } = runtime.naive
  const Page = defineComponent({
    name: 'NodeBabyPage',
    props: { host: { type: Object, required: true } },
    setup(props) {
      const initial = props.host.extension.value.settings
      const enabled = ref(initial.service_enabled === true)
      const port = ref(Number(initial.port ?? 9118))
      const status = ref({ running: false, ready: false, online: null, controllerRunning: false, phase: 'unknown' })
      const stale = ref(true), logOpen = ref(false), logs = ref([]), hiddenLines = ref(0), serviceLogs = ref(false)
      const restarting = ref(false)
      const busy = ref(false)
      const error = ref('')
      const note = ref('')
      const binding = ref('')
      const baseline = ref(JSON.stringify([enabled.value, port.value]))
      let disposed = false
      let timer = null, checking = false, restartBaseline = 0, restartDeadline = 0
      const dirty = computed(() => JSON.stringify([enabled.value, port.value]) !== baseline.value)
      const valid = computed(() => Number.isInteger(port.value) && port.value >= 1024 && port.value <= 65535)
      const unregister = props.host.registerSettings({
        dirty, valid, showHostActions: false,
        collect: () => ({ service_enabled: enabled.value, port: port.value }),
        reset: settings => {
          enabled.value = settings.service_enabled === true
          port.value = Number(settings.port ?? 9118)
          baseline.value = JSON.stringify([enabled.value, port.value])
        },
      })
      async function action(fn) {
        if (busy.value || disposed) return
        busy.value = true; error.value = ''; note.value = ''
        try { await fn() } catch (e) { if (!disposed) error.value = String(e?.message || e) }
        finally { if (!disposed) busy.value = false }
      }
      async function readStatus() {
        if (checking || disposed) return
        checking = true
        try {
          const current = await props.host.invoke('status')
          if (disposed) return
          status.value = current; stale.value = false
          if (error.value.startsWith('状态更新失败：')) error.value = ''
          if (!current.running) binding.value = ''
          if (restarting.value) {
            if ((current.manualRestarts || 0) > restartBaseline && current.running) {
              restarting.value = false; note.value = '客户端进程已重新启动；业务在线仍需单独确认。'
            } else if (current.phase === 'failed' || Date.now() > restartDeadline) {
              restarting.value = false; error.value = '尚未确认重启完成，请查看状态与诊断日志。'
            }
          }
        } catch (e) { if (!disposed) { stale.value = true; binding.value = '' }; throw e }
        finally { checking = false }
      }
      async function poll() {
        if (disposed) return
        if (document.visibilityState !== 'hidden' && !busy.value) {
          try { await readStatus() } catch (e) { if (!disposed) error.value = '状态更新失败：' + String(e?.message || e) }
        }
        if (!disposed) timer = setTimeout(poll, 5000)
      }
      async function restart() {
        restartBaseline = status.value.manualRestarts || 0
        const result = await props.host.invoke('restart')
        if (!result?.accepted) throw new Error('重启请求未被接受。')
        if (disposed) return
        restarting.value = true; restartDeadline = Date.now() + 30000; binding.value = ''
        note.value = '已请求重启，正在等待新的客户端进程。'
        await readStatus()
      }
      async function readLogs() {
        const result = await props.host.invoke('logs')
        if (!disposed) { logs.value = result.entries || []; hiddenLines.value = result.hiddenLines || 0; serviceLogs.value = result.serviceLogsAvailable === true; logOpen.value = true }
      }
      async function save() {
        if (!valid.value) return
        binding.value = ''
        if (await props.host.saveSettings()) {
          baseline.value = JSON.stringify([enabled.value, port.value])
          note.value = enabled.value
            ? '已保存启动设置。请先启用插件，再刷新查看实际进程状态；此设置会在插件重启后生效。'
            : '已保存停止设置。刷新确认进程已停止。'
          await readStatus()
        } else throw new Error('设置未保存，请重试。')
      }
      onMounted(async () => { await action(readStatus); if (!disposed) timer = setTimeout(poll, 5000) })
      onBeforeUnmount(() => { disposed = true; if (timer !== null) clearTimeout(timer); binding.value = ''; unregister?.() })
      const button = (label, fn, disabled = false) => h(NButton, {
        disabled: busy.value || disabled, loading: busy.value,
        onClick: () => action(fn),
      }, { default: () => label })
      return () => h('div', { class: 'nb-page' }, [
        h('h2', '节点小宝 NodeBaby · 0.1.0-r1'),
        h(NAlert, { type: 'warning', showIcon: false }, { default: () =>
          '实验版本 0.1.0 · 官方客户端 4.3.5-731。尚未在 NanoKVM Pro 实机验证。启动后客户端可访问网络并创建组网接口，管理端口可能监听局域网；请保留本地管理通道。' }),
        error.value ? h(NAlert, { type: 'error' }, { default: () => error.value }) : null,
        note.value ? h(NAlert, { type: 'info' }, { default: () => note.value }) : null,
        h('section', [
          h('h3', '当前状态'),
          h(NTag, { type: !stale.value && status.value.running ? 'success' : 'default' }, { default: () =>
            stale.value ? '状态未更新，暂无法确认' : ({ starting: '正在启动', running: '进程运行中', restarting: '正在重启', backoff: '等待自动恢复', failed: '频繁退出，已暂停恢复', stopped: '未运行' }[status.value.phase] || '状态未确认') }),
          h('p', stale.value ? '请刷新状态。上次结果不作为当前状态显示。' : status.value.online === false
            ? '业务在线：未在线（客户端未运行）' : status.value.online === true ? '业务在线：已确认' : '业务在线：未确认（暂无已验证的供应商接口）'),
          h('p', stale.value ? '' : `绑定端口：${status.value.ready ? '已就绪' : '未就绪'} · 自动恢复 ${status.value.automaticRestarts || 0} 次 · 手动重启 ${status.value.manualRestarts || 0} 次`),
          status.value.nextRetry && !stale.value ? h('p', '下次恢复时间：' + status.value.nextRetry) : null,
          h('small', '每 5 秒刷新；页面隐藏时暂停查询。端口就绪不代表账号已绑定或业务在线。'),
          button('刷新状态', readStatus),
          button(restarting.value ? '等待重启完成…' : '一键重启', restart, stale.value || !status.value.controllerRunning || dirty.value || restarting.value),
          button('获取官方绑定链接', async () => {
            const result = await props.host.invoke('binding')
            if (!disposed) binding.value = result.url || ''
          }, stale.value || !status.value.ready || restarting.value),
          binding.value ? h('p', [h('a', { href: binding.value, target: '_blank', rel: 'noopener noreferrer', referrerpolicy: 'no-referrer' }, '打开官方绑定页面'),
            h('small', ' 此链接可能含设备凭据，请勿分享；在官方页面核对设备身份。')]) : null,
        ]),
        h('section', [
          h('h3', '客户端设置'),
          h('label', [h('span', '运行客户端（插件启用时随宿主启动）'), h(NSwitch, {
            value: enabled.value, disabled: busy.value || restarting.value,
            'onUpdate:value': value => { enabled.value = value },
          })]),
          h('label', [h('span', '绑定端口'), h(NInputNumber, {
            value: port.value, min: 1024, max: 65535, precision: 0, disabled: busy.value || restarting.value,
            'onUpdate:value': value => { port.value = value },
          })]),
          h('p', '安装默认关闭。开启开关并保存会启动客户端；关闭后保存会停止。插件本身也需在 OneKVM 插件管理器中启用。'),
          button('保存并应用', save, !dirty.value || !valid.value || restarting.value),
        ]),
        h('section', [
          h('h3', '诊断日志'),
          button('查看日志', readLogs),
          h('p', '显示最近 100 条监管事件和已识别的客户端诊断，隐藏原始凭据、链接和未识别内容。'),
          h('p', '停用插件会由宿主停止整个扩展进程组；移除保留私有数据，彻底清除请使用宿主 purge。'),
        ]),
        h(NModal, { show: logOpen.value, preset: 'card', title: '最近诊断日志', style: { width: 'min(760px, 95vw)' },
          'onUpdate:show': value => { logOpen.value = value } }, { default: () => [
            button('刷新日志', readLogs), h('p', `已隐藏 ${hiddenLines.value} 行未识别原文。`),
            h('small', serviceLogs.value ? '已读取运行服务自己的日志视图。' : '服务日志暂不可用，显示保留的本插件日志。'),
            h('pre', { style: { maxHeight: '60vh', overflow: 'auto', whiteSpace: 'pre-wrap', overflowWrap: 'anywhere' } }, logs.value.length ? logs.value.map(e => `${e.time || ''} [${e.source}] ${e.message}`).join('\n') : '暂无可显示日志。'),
          ] }),
      ])
    },
  })
  runtime.register('nodebaby', {
    apiVersion: 1, component: Page,
    styles: ['.nb-page{display:grid;gap:16px;max-width:800px}.nb-page h2,.nb-page h3{margin:0 0 12px}.nb-page section{padding:16px;border:1px solid var(--n-border-color,#777);border-radius:8px}.nb-page label{display:flex;align-items:center;justify-content:space-between;gap:16px;margin:14px 0}.nb-page button{margin:4px 8px 4px 0}.nb-page small{display:block;margin-top:8px}.nb-page a{color:inherit;text-decoration:underline}'],
  })
})()
