# 节点小宝 OneKVM 原生扩展 0.1.0

实验构建，目标为用户记录中的 NanoKVM Pro / OneKVM ARM64 musl 系统。
已完成本地构建和隔离测试，尚未在真实设备安装、启动、绑定或验证组网。
本次工作没有连接用户设备，没有安装或运行设备上的客户端，没有修改设备。

## 交付内容

- `onekvm-extension-nodebaby.ipk`：完整安装载荷，约 12.4 MiB。
- 源码压缩包：扩展全部 Go、Vue 页面、构建与验证代码、测试、研究记录，
  以及原样保存的官方客户端 tgz。客户端属于闭源预编译组件，其内部源码不可获得。
- `build-report.json`、`package-verification.json`、`SHA256SUMS`：产物与校验记录。

扩展 ID 为 `nodebaby`，包名为 `onekvm-extension-nodebaby`。
不会使用 `tailscale` 的目录、包名、服务名或配置。

## 已检查的接口与构建条件

研究锁定的上游版本与来源见 `research/UPSTREAM-LOCK.json` 和
`research/研究与验证报告.md`。主要依据是官方 extension-host 的 manifest、
IPK 检查器、sandbox、生命周期和命令方法文档，以及官方 Tailscale 示例。

采用 `manifest_version: 1`、`api_version: 2`，常驻 entrypoint 配合命令 methods
数组；不同时声明短期 `controller`。管理页使用 `window.OneKVMPluginUI.v1`
注册为 `nodebaby`。宿主通过环境变量传入运行配置与私有数据目录。

已确认四个 ELF 均为 AArch64。`owjdxb`、`ownbsvman`、`owjdgjman`
使用 `/lib/ld-musl-aarch64.so.1`，DT_NEEDED 为 `libgcc_s.so.1` 与 `libc.so`。
`NodeBabyLinkService` 是静态 ELF。新的 Go 控制器也是静态 AArch64 ELF。
静态检查不能保证所有运行时路径、内核接口和子组件功能都兼容。

IPK 为 ar 容器，包含 `debian-binary`、`control.tar.gz`、`data.tar.gz`。
全部文件限定于 `/data/onekvm/apps/nodebaby/0.1.0/`；不包含包维护脚本、
系统服务文件、内核模块、系统库、绝对链接、SUID 文件或系统目录外载荷。

依赖：`onekvm-extension-host`、`onekvm-kernel-module-tun`、`musl`、`libgcc1`。
这些是平台依赖，不随本包覆盖。用户记录中的 TUN 已可用，仍需以安装时宿主
的依赖与内核 ABI 检查为准。不要使用 `--force-*` 绕过检查。

包 Architecture 使用用户已安装 Tailscale 包中记录的 `aarch64_cortex-a53`；
manifest architecture 则使用宿主要求的 `aarch64`，两者用途不同。

## 安装说明（仅供未来用户自行决定执行）

本次没有执行以下设备命令。建议先保留本地有线管理通道。

1. 先校验 IPK 的 SHA256，与同目录 `SHA256SUMS` 对照。
2. 通过 OneKVM 插件管理器上传本地 IPK，并**取消“安装后启用”**。
   若界面或宿主不支持安全关闭安装，先停止，核对宿主版本和 CLI 功能。
3. 对具有本文所列 CLI 的宿主，也可在已将文件自行传到设备后使用：

```sh
onekvm-extension install-local --enable-after-install=false < onekvm-extension-nodebaby.ipk
onekvm-extension validate nodebaby 0.1.0
onekvm-extension detail nodebaby
```

不要改用直接解压到系统目录、手工覆盖文件或执行官方一键安装脚本。
本包 `default_enabled=false`，设置 `service_enabled=false`；即使安装界面误选
启用，默认设置也不会启动节点小宝客户端。宿主自身仍可能完成插件配置初始化。

开启使用属于后续实机测试阶段：先启用 `nodebaby` 插件，打开插件页面，
打开“运行客户端”并保存。宿主负责创建服务和传递配置。保存其他配置会重启
该插件的服务。设置为运行且插件保持启用后，后续宿主恢复/设备重启会再次启动。
若需要仅查看插件管理页而不运行客户端，保持“运行客户端”关闭。

客户端本地管理端口默认 `9118`，离线检查已观察到监听 `0.0.0.0`；它会暴露
到设备可达网络，并非仅 loopback。扩展只从 loopback 读取绑定跳转，不添加
公网转发、Web 代理或自动打开外部页面。不要把该端口映射到公网。

用户显式点击“获取官方绑定链接”后，控制器检查该监听端口确属其监管的进程树，
只读取跳转头，不跟随跳转；返回的链接必须为允许列表中的官方 HTTPS
`/istore/` 地址。若未来供应商改变域名或路径，返回错误，不自动放宽规则。
绑定链接可能含设备凭据，请勿分享。绑定结果和网络可用性需在官方页面与实机确认。

## 生命周期、数据与回滚

安装载荷：`/data/onekvm/apps/nodebaby/0.1.0/`，由宿主只读保护。
可写私有数据：宿主传入的 `$ONEKVM_EXTENSION_DATA`，当前官方默认路径是
`/data/onekvm/app-data/nodebaby`。不采用旧对话中推测的 extensions 数据路径。
配置从 `$ONEKVM_EXTENSION_CONFIG/config.json` 只读获取。

首次启动在私有数据下建立工作副本 `work/0.1.0/owjdxb`，保留官方相对目录布局。
每次启动都会校验包内哈希，并用包内字节重新发布执行文件，避免直接启动上次
遗留的未知版本。状态存储位于 `store/`，临时路径为 `tmp/`，不会写 `/etc`、
`/usr` 或其他插件目录。软件包内不包含原厂 start.sh/stop.sh；serv.sh 已替换为
仅启动指定组件的脚本，移除了清理扫描及厂商停止命令。

主程序以 `-s` 前台方式运行，不使用 `-d`。它仍会产生工作子进程。
控制器启用 Linux subreaper，将脱离会话的后代重新归属自身；停止时按真实祖先
关系、进程启动时间和 pidfd 定向发送 TERM，超时发送 KILL，回收子进程。
从不主动执行 `killall`、`pkill` 或客户端 `--kill=yes`。宿主的整个服务 cgroup
是最终清理边界。状态记录包含本次开机 ID，避免重启后误用旧 PID。

包仅请求 `network` 与 `network-admin`，不请求 `host-root` 或
`host-unrestricted`。保持宿主的只读系统、私有临时目录和其他限制。闭源客户端
联网后自身可能执行下载、组网和网络配置操作；尚未完成所有行为审计，不能承诺
它完全不影响宿主路由或与另一 VPN 的并存。真实网络组件是否能在非 root 身份及
现有能力集下工作，是实机重点验证项，失败时应先停止并诊断，不自动扩大权限。

停止可在页面关闭运行开关并保存，或通过宿主：

```sh
onekvm-extension stop nodebaby
onekvm-extension disable nodebaby
```

删除安装载荷但保留配置和数据：

```sh
onekvm-extension remove onekvm-extension-nodebaby
```

确认不再需要账号绑定数据后，彻底删除：

```sh
onekvm-extension purge nodebaby
```

`purge` 会删除插件私有数据，应先另行备份。不要手工删除/覆盖 Tailscale 文件。
已安装插件的升级/同版本重装应使用宿主事务路径，由宿主保存原配置、载荷和数据
快照，激活失败时回滚。该机制来自官方源码，尚未在此包的真实安装中验收。
若安装失败，保留宿主错误与事务快照，不绕过健康检查或强行写入。

## 本地检查结果和界限

已通过：Go 编译与测试、前后台进程监管替身测试（含 setsid、忽略 TERM、KILL
升级清理及保留无关进程）、哈希篡改/链接拒绝、配置校验、旧开机状态拒绝、
绑定 URL 检查、受限输出日志，以及页面注册和默认不开启检查。
IPK 通过独立检查器：容器格式、压缩、控制字段、私有路径、可执行权限、ELF、
运行时哈希和关闭默认值均通过。该检查器依据官方规则实现，未替代真实宿主验证。

官方客户端只在本机临时 chroot、独立 PID/用户/挂载/网络命名空间中做过限时
QEMU 检查。网络不可达，无外部账号绑定，无真实 TUN；观察到 `-s` 保持前台、
生成工作进程、私有状态路径与监听端口，定向 TERM 后前台进程退出。
命名空间最终销毁全部剩余子进程，因此不能将这次观察算作官方全部子进程
自然退出已验证。新的控制器清理逻辑使用替身进程进行了独立测试。
本地模拟使用 Alpine musl 1.2.5，不是目标设备 musl 1.2.6 的完整系统副本。

最终 ARM64 控制器在 QEMU 下的关闭状态健康检查与状态查询已通过，未产生
客户端进程。组合启动在 `PR_SET_CHILD_SUBREAPER` 返回 `EINVAL` 时提前退出，
按设计拒绝继续运行；该 ARM64 组合检查没有通过。原生 Linux 的监管测试中
同一调用成功。保留此启动保护，不能把模拟器失败当作实机成功或据此放宽权限。

补充组合检查已通过：使用同一份 Go 源码编译的原生 x86_64 控制器，在无网络
chroot 中通过本机 binfmt/QEMU 启动官方 ARM64 客户端，状态返回 running=true、
ready=true；进程树包含控制器、主程序和工作子进程。对控制器定向 TERM 后退出
0，状态回到 running=false，独立 PID 空间内无残留客户端进程。此检查验证源码
监管逻辑和官方客户端的配合，不等于最终 ARM64 控制器或真实设备的完整启停验收。

尚未验证：目标设备实际安装/卸载/升级/失败回滚、真实 UI 外观与宿主 API 版本、
非 root 连接服务完整行为、绑定/解绑、TUN 与路由/DNS/防火墙、Tailscale 共存、
重启恢复、内存/CPU 长时间负载、闭源自动更新和异常断电后的所有边界。
无法证明闭源组件的完整文件或网络访问行为。不要把测试版用于唯一的远程通道。

页面只展示扩展生命周期事件，不返回可能含凭据的原厂输出。`vendor-output.log`
权限为 0600、大小上限 1 MiB；厂商自行写入的内部日志不受此 stdout 限额约束，
长时间实机测试需检查私有数据占用。内存 192 MiB、CPU 50%、任务 96 的配置为
初始保护值，尚无真实负载数据证明它们足够。

## 离线重建

Linux / WSL 环境需要 Go >= 1.24、Python >= 3.11；无第三方 Go 模块与 Python 库。
构建时不连接设备、不安装插件、不执行官方客户端，也不联网下载 Go 依赖。

```sh
go test -count=1 -v ./...
python3 build.py --go /path/to/go --out dist
python3 verify_ipk.py dist/onekvm-extension-nodebaby.ipk
# 可选：Node.js 页面逻辑检查
node tests/page.test.cjs
```

也可使用 `make GO=/path/to/go`、`make test`、`make verify`。
默认源码目录 `vendor/` 已包含校验固定的原始官方 tgz。
更换 `--client` 不能绕过固定 SHA256；升级客户端需明确修改锁定版本、重新做
依赖和行为检查。构建时间戳和 gzip 元数据固定；使用相同 Go 工具链与源码，
重复构建得到相同 IPK。本次使用 Go 1.27.4，需与自己的工具版本对照。
默认架构与用户设备记录一致；若其他设备只接受 `aarch64`，可重新构建时显式
指定 `--architecture aarch64`，不要直接修改现成 IPK 的控制字段。

原厂二进制保留原始权利，不受扩展 MIT 许可证重新授权。公开再分发前需核对
供应商条款，见 `THIRD_PARTY_NOTICES.txt`。本包并非 OneKVM 或节点小宝官方发布。
