# r1 接口、边界与验证依据

本轮保持既有 OneKVM API v2 和 command methods 架构，新增 `restart` 方法，
未增加权限。状态和日志为只读方法；restart 请求使用私有 Unix HTTP socket，
socket 位于宿主 `$ONEKVM_EXTENSION_SOCKET` 运行目录，测试环境使用 tmpfs 挂载。
核对 SO_PEERCRED 的 UID 和客户端可执行文件。停止/配置仍由宿主管理。

状态直接检查当前 boot ID、进程启动时间、进程是否为 zombie、祖先关系，以及
监听 socket inode 的实际进程归属。新监管状态描述 starting/running/backoff/
failed/restarting，不靠固定“已启动”标记冒充运行状态。

已检查的官方 Linux 文档描述本地 9118 绑定入口，没有在该页提供业务在线 API：
[Linux 使用说明](https://iepose.com/helpcenter_v3/docs/2.3-Linux%26Ubuntu.html)。
这只是对当前查阅文档的观察，不是断言厂商不存在任何其他接口。
静态客户端出现 /sys/info、心跳、管理和 RPC 字符串，未验证它们的只读在线
语义，因此没有调用未知管理接口或把 TCP 连接、激活码、日志当作在线证据。
用户已选择在此条件下显示“业务在线未确认”。

本地 GPG 索引签名参考 [opkg 签名说明](https://nilrt-docs.ni.com/opkg-keyrings/opkg-keyrings_index.html)
以及 [Yocto 的 GPG feed 验证说明](https://docs.yoctoproject.org/pipermail/yocto/2017-August/037395.html)：
Packages.asc 是对未压缩 Packages 的脱离式签名。另提供二进制 Packages.sig。
索引中的 SHA256sum 和 Size 约束 IPK 字节，IPK 另有自身脱离式签名。

密钥生成与加密备份遵循 [GnuPG key management](https://www.gnupg.org/documentation/manuals/gnupg/OpenPGP-Key-Management.html)
的 batch/loopback/passphrase-file 用法；签名不通过命令参数传递口令内容。
没有 keyserver、用户默认 keyring 或设备系统信任库写入。

OneKVM 的第三方源注册、公钥要求及共享 keyring 边界沿用此前固定版本
`9c7fe82ea200f7ace89ed2c74f5336235140a293` 的 command-method 文档。
当前重取 GitHub 源码时连接器/网络不可用，因而没有声称复核了更新宿主版本。
精确设备宿主版本、可信官方源的过期元数据要求和实际刷新行为必须另行验收。
此软件源没有替换平台依赖，没有安装、导入设备信任或公开发布。

日志采用封闭诊断允许列表，仅输出固定中文说明；不保留任何原始行捕获片段。
离线实测确认本版本内部日志仍落在 /tmp/.owjdxb/onewu.log。由于方法 helper 和
常驻服务的 PrivateTmp 不同，读取必须由运行服务在自身命名空间完成，经同一
私有 Unix 接口返回已脱敏内容。没有绕过宿主临时目录隔离。
这会有意丢弃部分排错细节。客户端内部日志没有可信业务在线接口语义，
读取它们只用于诊断展示，不改变 online 字段。
