// SPDX-License-Identifier: MIT
package main

import (
	"bytes"
	"encoding/json"
	"errors"
	"io"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"time"
)

type LogEntry struct {
	Time    string `json:"time,omitempty"`
	Source  string `json:"source"`
	Code    string `json:"code"`
	Message string `json:"message"`
}

var eventMessages = map[string]string{
	"CLIENT_STARTED": "已发起客户端启动。", "UNEXPECTED_EXIT": "客户端异常退出，已清理其子进程。",
	"AUTO_RETRY": "等待退避后自动恢复。", "CRASH_LOOP": "一分钟内异常退出五次，已暂停自动恢复；修复后可手动重启。",
	"RESTART_REQUESTED": "已接收手动重启请求。", "SUPERVISOR_STOPPED": "客户端监管已停止。",
	"CLEANUP_FAILED": "子进程未确认清理完成，已暂停再次启动；可停止整个插件后检查。",
}

func readPrivate(l Layout, relative string, max int64) ([]byte, error) {
	if filepath.IsAbs(relative) || strings.Contains(relative, "..") || strings.Contains(relative, "\\") {
		return nil, errors.New("unsafe log path")
	}
	p := l.Data
	parts := strings.Split(filepath.ToSlash(relative), "/")
	for _, part := range parts[:len(parts)-1] {
		p = filepath.Join(p, part)
		st, e := os.Lstat(p)
		if e != nil || !st.IsDir() || st.Mode()&os.ModeSymlink != 0 {
			return nil, errors.New("unsafe private directory")
		}
	}
	fd, e := syscall.Open(filepath.Join(l.Data, relative), syscall.O_RDONLY|syscall.O_NOFOLLOW|syscall.O_NONBLOCK|syscall.O_CLOEXEC, 0)
	if e != nil {
		return nil, e
	}
	f := os.NewFile(uintptr(fd), relative)
	defer f.Close()
	st, e := f.Stat()
	if e != nil || !st.Mode().IsRegular() {
		return nil, errors.New("not a private regular file")
	}
	skip := st.Size() > max
	if skip {
		if _, e = f.Seek(-max, io.SeekEnd); e != nil {
			return nil, e
		}
	}
	b, e := io.ReadAll(io.LimitReader(f, max))
	if skip {
		if i := bytes.IndexByte(b, '\n'); i >= 0 {
			b = b[i+1:]
		} else {
			b = nil
		}
	}
	return b, e
}
func recordEvent(l Layout, code string) {
	message, ok := eventMessages[code]
	if !ok {
		return
	}
	entry := LogEntry{time.Now().UTC().Format(time.RFC3339), "controller", code, message}
	b, _ := json.Marshal(entry)
	old, _ := readPrivate(l, "events.jsonl", 96<<10)
	old = append(old, append(b, '\n')...)
	if len(old) > 128<<10 {
		old = old[len(old)-(96<<10):]
		if i := bytes.IndexByte(old, '\n'); i >= 0 {
			old = old[i+1:]
		}
	}
	// Only the single supervisor loop writes history. Replace atomically; no raw
	// vendor output, credentials, URL parameters or arbitrary error text enters it.
	f, e := os.CreateTemp(l.Data, ".events-*")
	if e != nil {
		return
	}
	name := f.Name()
	defer os.Remove(name)
	_ = f.Chmod(0600)
	_, e = f.Write(old)
	ce := f.Close()
	if e == nil && ce == nil {
		_ = os.Rename(name, filepath.Join(l.Data, "events.jsonl"))
	}
}
func vendorDiagnostic(line string) (string, string) {
	if len(line) > 4096 {
		return "", ""
	}
	// Closed allowlist: never return any captured substring from the raw line.
	rules := []struct{ needle, code, message string }{
		{"Network unreachable", "NETWORK_UNREACHABLE", "客户端报告网络不可达。"},
		{"Permission denied", "PERMISSION_DENIED", "客户端报告权限不足。"},
		{"Error loading shared library", "LIBRARY_MISSING", "客户端报告缺少动态运行库。"},
		{"Address already in use", "PORT_CONFLICT", "客户端报告端口被占用。"},
		{"read mounts failed", "MOUNTS_UNREADABLE", "客户端无法读取挂载信息。"},
		{"create conn to", "CONNECT_ATTEMPT", "客户端尝试建立服务连接；此记录不代表已在线。"},
		{"create succ, bind:", "LISTENER_CREATED", "客户端记录了监听端口创建。"},
		{"owjdxb start, .ver=", "CLIENT_INITIALIZED", "客户端主模块已初始化。"},
	}
	for _, r := range rules {
		if strings.Contains(line, r.needle) {
			return r.code, r.message
		}
	}
	return "", ""
}

type LogResponse struct {
	Entries              []LogEntry `json:"entries"`
	Hidden               int        `json:"hiddenLines"`
	Redacted             bool       `json:"redacted"`
	Limit                int        `json:"limit"`
	ServiceLogsAvailable bool       `json:"serviceLogsAvailable"`
}

func readLogs(l Layout) LogResponse { return readLogsInNamespace(l, false) }
func readLogsInNamespace(l Layout, service bool) LogResponse {
	entries := []LogEntry{}
	hidden := 0
	if b, e := readPrivate(l, "events.jsonl", 64<<10); e == nil {
		for _, line := range bytes.Split(b, []byte{'\n'}) {
			var event LogEntry
			if json.Unmarshal(line, &event) == nil {
				if message, ok := eventMessages[event.Code]; ok {
					t, e := time.Parse(time.RFC3339, event.Time)
					if e == nil {
						entries = append(entries, LogEntry{t.UTC().Format(time.RFC3339), "controller", event.Code, message})
					}
				}
			}
		}
	}
	sources := []struct {
		layout Layout
		file   string
	}{{l, "vendor-output.log"}, {l, "tmp/.owjdxb/onewu.log"}}
	// Only the running extension service reads its own PrivateTmp namespace.
	// A short-lived method helper must never read an unrelated global /tmp.
	if service && os.Getenv("ONEKVM_EXTENSION_ID") == "nodebaby" {
		sources = append(sources, struct {
			layout Layout
			file   string
		}{Layout{Data: "/tmp"}, ".owjdxb/onewu.log"})
	}
	for _, source := range sources {
		if b, e := readPrivate(source.layout, source.file, 32<<10); e == nil {
			for _, line := range strings.Split(string(b), "\n") {
				if line == "" {
					continue
				}
				code, message := vendorDiagnostic(line)
				if code == "" {
					hidden++
					continue
				}
				entry := LogEntry{Source: "client", Code: code, Message: message}
				if len(entries) > 0 && entries[len(entries)-1] == entry {
					continue
				}
				entries = append(entries, entry)
			}
		}
	}
	if len(entries) > 100 {
		entries = entries[len(entries)-100:]
	}
	return LogResponse{entries, hidden, true, 100, service}
}
