#!/usr/bin/env python3
"""Independent artifact checks based on the pinned host's src/ipk.rs rules.
This is not a replacement for running the actual host on the target device.
"""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import tarfile
from build import BINARIES, elf_info

def require(condition,message):
    if not condition: raise ValueError(message)

def members(data):
    require(data[:8]==b'!<arch>\n','invalid ar magic')
    pos=8; result={}
    while pos<len(data):
        header=data[pos:pos+60];require(len(header)==60 and header[-2:]==b'`\n','invalid ar header')
        name=header[:16].decode().strip().rstrip('/');size=int(header[48:58])
        require(name not in result and 0<=size<=256<<20,'invalid member')
        result[name]=data[pos+60:pos+60+size]
        require(len(result[name])==size,'truncated member')
        pos+=60+size+size%2
    require(pos==len(data),'invalid padding');return result

def tar_entries(data):
    result={}
    with tarfile.open(fileobj=io.BytesIO(data),mode='r:gz') as tar:
        for e in tar:
            name=e.name.removeprefix('./');p=PurePosixPath(name)
            require(not name.startswith('/') and '..' not in p.parts and '\\' not in name,'unsafe tar path')
            require(name not in result and e.isfile(),'duplicate or nonregular tar member')
            result[name]=(e,tar.extractfile(e).read())
    return result

def verify(path):
    data=path.read_bytes();m=members(data)
    require(set(m)=={'debian-binary','control.tar.gz','data.tar.gz'},'unexpected ar members')
    require(m['debian-binary']==b'2.0\n','invalid debian-binary')
    ctrl=tar_entries(m['control.tar.gz']);require(set(ctrl)=={'control'},'maintenance scripts forbidden')
    fields=dict(line.split(': ',1) for line in ctrl['control'][1].decode().splitlines())
    require(fields['Package']=='onekvm-extension-nodebaby','wrong package')
    require(fields['Version']=='0.1.0-r1','wrong package revision')
    require(fields['Architecture'] in ['aarch64_cortex-a53','aarch64'],'wrong opkg architecture')
    require(fields['X-OneKVM-Extension-Version']=='0.1.0','missing extension version')
    require(fields['Depends']=='onekvm-extension-host, onekvm-kernel-module-tun, musl, libgcc1','unexpected dependencies')
    entries=tar_entries(m['data.tar.gz']);prefix='data/onekvm/apps/nodebaby/0.1.0/'
    require(all(name.startswith(prefix) for name in entries),'payload escapes private extension root')
    manifest=json.loads(entries[prefix+'manifest.json'][1])
    require(manifest['api_version']==2 and manifest['id']=='nodebaby','manifest contract mismatch')
    require(manifest['default_enabled'] is False,'default enabled')
    require(manifest['settings_schema']['properties']['service_enabled']['default'] is False,'client starts by default')
    require(manifest['permissions']==['network','network-admin'],'unexpected privileges')
    commands=[manifest['entrypoint'],manifest['healthcheck']['command'][0]]+[x['command'][0] for x in manifest['methods']]
    for command in commands:
        entry,_=entries[prefix+command];require(entry.mode&0o111,'command is not executable')
    controller=elf_info(entries[prefix+manifest['entrypoint']][1]);require(controller['interpreter'] is None and not controller['needed'],'controller not static')
    index=json.loads(entries[prefix+'runtime-index.json'][1])
    for item in index:
        entry,b=entries[prefix+'runtime/owjdxb/'+item['path']]
        require(hashlib.sha256(b).hexdigest()==item['sha256'],'runtime hash mismatch')
        require(bool(entry.mode&0o111)==item['executable'],'runtime mode mismatch')
    for name in BINARIES:elf_info(entries[prefix+'runtime/owjdxb/'+name][1])
    for component in ['ownbsv','owjdgj']:
        script=entries[prefix+'runtime/owjdxb/'+component+'/serv.sh'][1]
        require(b'killall' not in script and b'--kill=' not in script and b'find ' not in script,'unsafe service script')
    require(not any(x.endswith('/start.sh') or x.endswith('/stop.sh') for x in entries),'vendor lifecycle scripts packaged')
    require(all(not e.mode&0o6000 for e,b in entries.values()),'setuid/setgid payload')
    return {'passed':True,'files':len(entries),'architecture':fields['Architecture'],'sha256':hashlib.sha256(data).hexdigest(),
            'checks':['ar/gzip/control','no package scripts','private payload paths','manifest/command modes','disabled defaults','AArch64/static controller','vendor hashes/dependencies','replacement scripts'],
            'device_install_tested':False}

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('ipk',type=Path);args=p.parse_args()
    print(json.dumps(verify(args.ipk),indent=2))
