# 节点小宝 OneKVM 扩展 0.1.0-r1

这是对 0.1.0 的维护修订，manifest 版本仍为 `0.1.0`，IPK 修订为 `r1`。
默认不启用插件、默认不启动客户端。没有访问或修改用户设备，没有发布软件源。

## 本轮改进

- 页面每 5 秒查询真实进程与监听端口，隐藏页面时暂停，卸载页面时清理计时器。
  查询失败时标记状态过期，不沿用旧的“运行中”提示。
- 业务在线状态明确区分：主程序未运行时为未在线；主程序运行时为“未确认”。
  用户已确认没有已验证的供应商在线 API，因此没有用端口、TCP 连接或历史日志
  推断“已绑定、已联网、组网成功”。API 中对应 `online: false / null`。
- 一键重启通过扩展私有 Unix socket 请求同一个监管进程。先停止旧进程树，再启动
  新进程；按钮先显示已请求，观察到重启次数和新进程后才显示完成。不会启用已
  关闭的客户端，有未保存设置时也不能重启。其他可执行程序的本地请求会被拒绝。
- 日志弹窗显示最近 100 条监管事件和已识别的客户端诊断，支持刷新。
  运行服务在自己的 PrivateTmp 中读取原厂日志，再通过私有接口返回脱敏结果；
  短期方法进程不跨目录读取其他服务的临时文件。服务关闭时仍可查看保留的监管记录。
  不返回原始绑定链接、设备码、token、主机信息或未知原文。日志读取路径固定，
  拒绝链接、FIFO、目录和路径穿越；接口没有任意文件读取功能。
- 监管进程发现主程序退出时先清理后代，再按 1、2、4、8 秒退避自动重试。
  60 秒内退出五次则暂停自动恢复，保留监管和日志，修复后可手动重启。
  退出码为零但不是用户停止也按意外退出处理。退避期间停止会取消再次拉起。
  清理未确认完成时禁止再启动一份客户端。
- 新建独立 RSA3072 GPG 签名密钥，软件源索引和 IPK 均有脱离式签名。
  公钥、完整指纹和公开源一起交付；私钥、口令和撤销证书独立留在本地。

自动恢复次数、手动重启次数属于当前监管进程会话，宿主重启后会重新计数。
内部业务子组件失效但主程序没有退出的情况，仍需真实设备和供应商接口验收；
本轮没有增加未经验证的网络探测或猜测式业务健康检查。

## 文件与兼容范围

客户端仍为原始官方 `owjdxb_linux_muslarm64_4.3.5-731.tgz`，SHA256：
`16749ee14a6b4e4a7f09a01b4b4955bb05c89b099ad369cc0067fc3e1d82cd3a`。
三个管理程序需要 musl loader、libgcc_s.so.1 和 libc.so，连接服务为静态 AArch64。
控制器是静态 AArch64 Go 程序。依赖检查详情见 `build-report.json`。

IPK 架构 `aarch64_cortex-a53` 与用户此前的已安装包记录一致；manifest 架构为
`aarch64`。平台依赖为 extension-host、匹配内核的 TUN 包、musl 和 libgcc1。
这些系统包没有包含在本 IPK 中，也没有被替换。

安装载荷全部在 `/data/onekvm/apps/nodebaby/0.1.0/`，没有包维护脚本、系统服务
文件或系统目录载荷。运行数据使用宿主 `$ONEKVM_EXTENSION_DATA`，官方默认值
为 `/data/onekvm/app-data/nodebaby`。配置从宿主运行配置目录只读获取。
重启控制 socket 使用宿主提供的 `$ONEKVM_EXTENSION_SOCKET/nodebaby-control.sock`，
不要求持久数据文件系统支持 Unix socket。独立命令测试未传该变量时才使用私有数据目录回退。
权限仍仅为 `network`、`network-admin`；没有新增 root、不受限主机或软件包管理权限。
Tailscale 的包、目录、配置、服务均不属于本插件的写入范围。

生命周期仍采用前台 `-s`、subreaper、pidfd、启动时间和祖先关系校验，宿主的
cgroup 是最后清理边界。不会调用厂商 stop.sh、`--kill=yes`、killall 或 pkill。
原始厂商启动/停止脚本不打包，组件启动脚本去掉了全局停止和扫描删除逻辑。

## 安装与回滚（本次未在设备执行）

先对照交付目录 `SHA256SUMS` 校验文件，再通过 OneKVM 插件管理器安装 IPK，
取消“安装后启用”。支持相应 CLI 的宿主可使用：

```sh
onekvm-extension install-local --enable-after-install=false < onekvm-extension-nodebaby_0.1.0-r1_aarch64_cortex-a53.ipk
onekvm-extension validate nodebaby 0.1.0
```

若从 r0 升级，使用宿主的安装事务，保持同一插件 ID；不要手工覆盖目录。
宿主应对同版本修订重装进行快照、健康检查及失败回滚。此行为尚未真实验收，
应先保留配置与私有数据备份，不使用任何 `--force-*` 参数。
已有启用意图可能在升级后被保留。想离线审查时先通过宿主停用旧插件。

后续明确同意设备测试后，才启用插件并在页面打开运行开关保存。
客户端默认管理端口 9118，会监听设备可达网络；不要做公网端口映射。
绑定链接仅在用户点击时从本地监听读取，限定官方 HTTPS 域名和固定路径，
不会自动跟随跳转或自动完成账号绑定。

停止、移除或彻底清除使用宿主命令：

```sh
onekvm-extension stop nodebaby
onekvm-extension disable nodebaby
onekvm-extension remove onekvm-extension-nodebaby
# 仅在确认不再需要节点身份和私有数据后：
onekvm-extension purge nodebaby
```

`remove` 保留私有数据，`purge` 删除它们。失败时保留宿主事务错误与快照，
不要执行官方全局卸载脚本或修改另一 VPN 作为补救。

## 独立签名软件源

公开源根目录为 `feed/aarch64_cortex-a53/`，包含：

- `Packages`、相同内容的 `Packages.gz`。
- 对未压缩 `Packages` 的 ASCII-armored 脱离式签名 `Packages.asc`，以及二进制
  脱离式签名 `Packages.sig`。
- 完整 IPK 和它的 `*.ipk.asc` 签名。
- `nodebaby-feed-public.asc`、`FINGERPRINT.txt`、注释状态的 `source.conf.example`。

专用签名公钥完整指纹：
`7F3D21B869A478AFA7992C2B352A75F8531979C0`。
有效期按 GnuPG 生成时的 2y 设置。签名证明发布者密钥和字节完整性，
不代表 OneKVM 或节点小宝官方认证。

该源已在本地签名和验证，尚未托管到 HTTPS 地址，也未添加到设备。
后续只需将**公开源目录**放到选定 HTTPS 路径，在 OneKVM 的软件源管理界面中
添加唯一源名称 `nodebaby-independent`，使用类似下面的地址并单独粘贴公钥：

```text
src/gz nodebaby-independent https://YOUR-HOST/path/aarch64_cortex-a53
```

`YOUR-HOST` 是待确定的托管地址，不是已发布服务。核对完整指纹再信任。
通过宿主源管理保存公钥，不手工覆盖系统 GPG 密钥库，不关闭签名检查。
基础依赖仍由设备现有可信平台源提供，本独立源仅发布 nodebaby。
实际设备上的 opkg/宿主签名源兼容和刷新流程仍需验收；没有声称已通过设备测试。

私钥备份不在公开软件源 ZIP 或完整源码 ZIP 内。此次本地工作目录的
`work/signing-private/` 保存加密私钥、随机口令、撤销证书和指纹；Windows ACL
仅给当前用户和 SYSTEM 访问。请将私钥与口令分别备份到安全离线位置，
只公开 `outputs/feed/`，不要公开整个工作目录或签名私有目录。
签名工具使用临时 GPG home，不改当前用户默认 keyring，不上传 keyserver。

## 测试和未验证项目

当前测试记录见 `research/R1-TEST-RESULTS.json` 及同目录日志。
Go 测试含竞态检测，覆盖异常恢复、零退出码恢复、连续崩溃熔断、手动修复重启、
停止取消重试、无关进程保留、未经授权的本地重启拒绝、路径和凭据保护等。
页面逻辑测试覆盖状态过期、未确认在线、重启请求与完成的区分、隐藏暂停和销毁清理。
这些是逻辑测试，不等同于真实 OneKVM 浏览器外观验收。

IPK 做了结构、权限、依赖和哈希检查；相同工具链两次构建字节一致。
GPG 检查使用仅导入公钥的新 keyring，验证签名、压缩索引一致性和 IPK 哈希，
并确认篡改索引/安装包和缺失公钥都会失败。公开目录不含私钥。

最终 ARM64 控制器仍有前次记录的 QEMU subreaper 限制；关闭状态健康与状态
查询可以在 QEMU 验证。组合监管测试采用同份 Go 源码的本机版本，配合隔离
环境中运行的官方 ARM64 客户端。具体已完成结果以本轮测试报告为准。
测试环境没有外网、账号绑定、真实 TUN，也不是目标 musl 1.2.6 的完整系统副本。

未验证：真实设备安装/升级回滚、非 root 能力集、最终 ARM64 启停、UI 实际外观、
账号绑定、业务在线、组网/DNS/路由/防火墙、Tailscale 共存、内存与长期负载、
厂商组件内部异常及自动下载行为。资源保护值未依据真实设备负载调优。
原厂 stdout 仍限制 1 MiB；厂商自行写入的内部日志没有完整的存储配额保证。
源码包中的 r0 报告和说明均标为历史记录，不能当作 r1 的新验收结果。

## 重建与验证

Linux / WSL：Go >= 1.24、Python >= 3.11；页面逻辑测试额外需要 Node.js。
签名和验证需要 GnuPG。本次编译使用 Go 1.27.4，Go/Python 均无第三方依赖。

```sh
go test -race -count=1 -v ./...
node tests/page-r1.test.cjs
python3 build.py --go /path/to/go --out dist
python3 verify_ipk.py dist/onekvm-extension-nodebaby_0.1.0-r1_aarch64_cortex-a53.ipk
```

生成新源时必须明确指定私钥备份、口令文件和完整指纹；签名材料不进入软件源：

```sh
# 仅初次创建，输出目录必须为空：
python3 new_feed_key.py --private-dir /safe/private-signing
# 使用已有备份重新签署：
python3 make_feed.py --ipk dist/onekvm-extension-nodebaby_0.1.0-r1_aarch64_cortex-a53.ipk \
  --out dist/feed/aarch64_cortex-a53 --secret-key /safe/private-signing/secret-key.asc \
  --passphrase-file /safe/private-signing/passphrase.txt --fingerprint FULL_PRIMARY_FINGERPRINT
python3 verify_feed.py dist/feed/aarch64_cortex-a53
```

不要为每次构建重新创建密钥；沿用并安全保管专用密钥。输出目录要求为空，
防止混入旧索引、未签名文件或私有材料。源码包含完整扩展及原始官方 tgz，
不包含供应商不可获得的闭源客户端源码。权利说明见 `THIRD_PARTY_NOTICES.txt`。
