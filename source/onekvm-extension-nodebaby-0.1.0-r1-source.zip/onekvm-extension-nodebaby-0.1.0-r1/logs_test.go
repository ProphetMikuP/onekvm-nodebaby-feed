// SPDX-License-Identifier: MIT
package main

import (
	"encoding/json"
	"os"
	"path/filepath"
	"strings"
	"syscall"
	"testing"
)

func TestLogsNeverReturnVendorSecrets(t *testing.T) {
	l := fixture(t)
	recordEvent(l, "CLIENT_STARTED")
	os.MkdirAll(filepath.Join(l.Data, "tmp/.owjdxb"), 0700)
	raw := "active_code=SECRET_A\nhttps://iepose.com/istore/?token=SECRET_B\nNetwork unreachable token=SECRET_C\nPermission denied sn=SECRET_D\n" + strings.Repeat("Z", 5000) + "\n"
	os.WriteFile(filepath.Join(l.Data, "tmp/.owjdxb/onewu.log"), []byte(raw), 0600)
	b, e := json.Marshal(readLogs(l))
	if e != nil {
		t.Fatal(e)
	}
	text := string(b)
	for _, secret := range []string{"SECRET_", "token=", "active_code", "iepose.com", "ZZZZ"} {
		if strings.Contains(text, secret) {
			t.Fatal("credential escaped", secret, text)
		}
	}
	if !strings.Contains(text, "NETWORK_UNREACHABLE") || !strings.Contains(text, "PERMISSION_DENIED") {
		t.Fatal("diagnostics lost", text)
	}
}
func TestPrivateReadsRejectLinksAndFifo(t *testing.T) {
	l := fixture(t)
	external := filepath.Join(t.TempDir(), "secret")
	os.WriteFile(external, []byte("SECRET"), 0600)
	os.Symlink(external, filepath.Join(l.Data, "vendor-output.log"))
	if _, e := readPrivate(l, "vendor-output.log", 4096); e == nil {
		t.Fatal("symlink accepted")
	}
	os.Symlink(filepath.Dir(external), filepath.Join(l.Data, "linked"))
	if _, e := readPrivate(l, "linked/secret", 4096); e == nil {
		t.Fatal("parent symlink accepted")
	}
	syscall.Mkfifo(filepath.Join(l.Data, "fifo"), 0600)
	if _, e := readPrivate(l, "fifo", 4096); e == nil {
		t.Fatal("fifo accepted")
	}
	for _, p := range []string{"../secret", "/etc/passwd"} {
		if _, e := readPrivate(l, p, 4096); e == nil {
			t.Fatal("unsafe path accepted")
		}
	}
}
func TestLogsIgnoreForgedMessagesAndBoundResults(t *testing.T) {
	l := fixture(t)
	os.WriteFile(filepath.Join(l.Data, "events.jsonl"), []byte("{\"code\":\"CLIENT_STARTED\",\"time\":\"2026-11-23T12:00:00Z\",\"message\":\"SECRET\"}\n"), 0600)
	for i := 0; i < 120; i++ {
		recordEvent(l, "AUTO_RETRY")
	}
	b, _ := json.Marshal(readLogs(l))
	if strings.Contains(string(b), "SECRET") {
		t.Fatal("forged message exposed")
	}
	var result struct {
		Entries []LogEntry `json:"entries"`
	}
	json.Unmarshal(b, &result)
	if len(result.Entries) != 100 {
		t.Fatal(len(result.Entries))
	}
}
