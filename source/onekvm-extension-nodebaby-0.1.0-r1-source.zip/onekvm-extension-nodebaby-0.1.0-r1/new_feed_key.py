#!/usr/bin/env python3
"""Create a dedicated passphrase-protected GPG signing key, entirely locally.
The private directory must never be uploaded as part of a public feed.
"""
import argparse,json,os,secrets,subprocess,tempfile
from pathlib import Path

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--private-dir',type=Path,required=True);a=p.parse_args()
 a.private_dir.mkdir(parents=True,exist_ok=True,mode=0o700)
 if any(a.private_dir.iterdir()):raise SystemExit('Private directory is not empty; refusing to replace an existing key.')
 phrase=a.private_dir/'passphrase.txt'
 fd=os.open(phrase,os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
 with os.fdopen(fd,'w') as f:f.write(secrets.token_urlsafe(48)+'\n')
 with tempfile.TemporaryDirectory(prefix='nodebaby-key-') as home:
  os.chmod(home,0o700)
  base=['gpg','--no-options','--homedir',home,'--batch','--pinentry-mode','loopback','--passphrase-file',str(phrase.resolve())]
  try:
   subprocess.run(base+['--quick-generate-key','NodeBaby Independent Feed 2026','rsa3072','sign','2y'],check=True)
   listing=subprocess.check_output(base+['--with-colons','--list-secret-keys'],text=True)
   fpr=next(line.split(':')[9] for line in listing.splitlines() if line.startswith('fpr:'))
   backup=subprocess.check_output(base+['--armor','--export-secret-keys',fpr])
   fd=os.open(a.private_dir/'secret-key.asc',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
   with os.fdopen(fd,'wb') as f:f.write(backup)
   (a.private_dir/'fingerprint.txt').write_text(fpr+'\n')
   revocation=Path(home)/'openpgp-revocs.d'/f'{fpr}.rev'
   if revocation.exists():
    fd=os.open(a.private_dir/'revocation-certificate.rev',os.O_WRONLY|os.O_CREAT|os.O_EXCL,0o600)
    with os.fdopen(fd,'wb') as f:f.write(revocation.read_bytes())
   print(json.dumps({'fingerprint':fpr,'algorithm':'RSA3072 signing primary','expires':'2 years','private_key_encrypted':True,'publicly_published':False}))
  finally:subprocess.run(['gpgconf','--homedir',home,'--kill','gpg-agent'],check=False)

if __name__=='__main__':main()
