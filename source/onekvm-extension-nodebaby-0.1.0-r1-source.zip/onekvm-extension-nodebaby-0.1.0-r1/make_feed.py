#!/usr/bin/env python3
"""Build a standalone signed opkg feed. Publishes no private signing material.
No device access, trust-store changes, HTTP uploads, or network requests.
"""
import argparse,gzip,hashlib,json,os,shutil,subprocess,tempfile
from pathlib import Path
from verify_ipk import members,tar_entries,verify

def build(ipk,out,secret,phrase,fpr):
 verify(ipk)
 if len(fpr)!=40 or any(c not in '0123456789ABCDEF' for c in fpr):raise ValueError('full uppercase primary fingerprint required')
 out.mkdir(parents=True,exist_ok=True)
 if any(out.iterdir()):raise ValueError('feed output must be empty, preventing stale unsigned or private content')
 data=ipk.read_bytes();ctrl=tar_entries(members(data)['control.tar.gz'])['control'][1].decode()
 fields=dict(line.split(': ',1) for line in ctrl.splitlines())
 filename=f"{fields['Package']}_{fields['Version']}_{fields['Architecture']}.ipk"
 (out/filename).write_bytes(data)
 index=(ctrl.rstrip()+'\n'+f'Filename: {filename}\nSize: {len(data)}\nSHA256sum: {hashlib.sha256(data).hexdigest()}\n\n').encode()
 (out/'Packages').write_bytes(index);(out/'Packages.gz').write_bytes(gzip.compress(index,mtime=0))
 with tempfile.TemporaryDirectory(prefix='nodebaby-publisher-') as home:
  os.chmod(home,0o700);base=['gpg','--no-options','--homedir',home,'--batch']
  try:
   subprocess.run(base+['--import',str(secret.resolve())],check=True,capture_output=True)
   listing=subprocess.check_output(base+['--with-colons','--list-keys',fpr],text=True)
   actual=next(line.split(':')[9] for line in listing.splitlines() if line.startswith('fpr:'))
   if actual!=fpr:raise ValueError('unexpected signing identity')
   public=subprocess.check_output(base+['--armor','--export',fpr]);assert b'PRIVATE KEY' not in public
   (out/'nodebaby-feed-public.asc').write_bytes(public);(out/'FINGERPRINT.txt').write_text(fpr+'\n')
   sign=base+['--pinentry-mode','loopback','--passphrase-file',str(phrase.resolve()),'--local-user',fpr+'!','--digest-algo','SHA256']
   for name,armor in [('Packages.asc',True),('Packages.sig',False),(filename+'.asc',True)]:
    target=out/('Packages' if name.startswith('Packages.') else filename)
    subprocess.run(sign+(['--armor'] if armor else [])+['--output',str((out/name).resolve()),'--detach-sign',str(target.resolve())],check=True,capture_output=True)
  finally:subprocess.run(['gpgconf','--homedir',home,'--kill','gpg-agent'],check=False)
 (out/'source.conf.example').write_text('# Configure through OneKVM source management after HTTPS hosting.\n# Paste nodebaby-feed-public.asc separately and check the full fingerprint.\n# src/gz nodebaby-independent https://YOUR-HOST/path/aarch64_cortex-a53\n')
 return {'fingerprint':fpr,'ipk':filename,'index_signature':'detached OpenPGP ASCII armor over uncompressed Packages','published':False,'device_trust_changed':False}

def main():
 p=argparse.ArgumentParser(description=__doc__);p.add_argument('--ipk',type=Path,required=True);p.add_argument('--out',type=Path,required=True);p.add_argument('--secret-key',type=Path,required=True);p.add_argument('--passphrase-file',type=Path,required=True);p.add_argument('--fingerprint',required=True);a=p.parse_args()
 print(json.dumps(build(a.ipk,a.out,a.secret_key,a.passphrase_file,a.fingerprint),indent=2))
if __name__=='__main__':main()
