// SPDX-License-Identifier: MIT
package main

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sync/atomic"
	"syscall"
	"time"
)

const packageRevision = "0.1.0-r1"

var errUnreaped = errors.New("descendant cleanup not confirmed")

type SupervisorState struct {
	BootID            string `json:"bootId"`
	Controller        Proc   `json:"controller"`
	Phase             string `json:"phase"`
	Attempts          int    `json:"attempts"`
	AutomaticRestarts int    `json:"automaticRestarts"`
	ManualRestarts    int    `json:"manualRestarts"`
	LastExit          string `json:"lastExit,omitempty"`
	NextRetry         string `json:"nextRetry,omitempty"`
	Updated           string `json:"updated"`
}
type LiveStatus struct {
	Status
	Revision          string `json:"revision"`
	ControllerRunning bool   `json:"controllerRunning"`
	Phase             string `json:"phase"`
	Online            *bool  `json:"online"`
	OnlineSource      string `json:"onlineSource"`
	CheckedAt         string `json:"checkedAt"`
	AutomaticRestarts int    `json:"automaticRestarts"`
	ManualRestarts    int    `json:"manualRestarts"`
	LastExit          string `json:"lastExit,omitempty"`
	NextRetry         string `json:"nextRetry,omitempty"`
}

func supervisorPath(l Layout) string { return filepath.Join(l.Data, "supervisor.json") }
func loadSupervisor(l Layout) (SupervisorState, error) {
	var s SupervisorState
	b, e := readPrivate(l, "supervisor.json", 16384)
	if e == nil {
		e = json.Unmarshal(b, &s)
	}
	return s, e
}
func supervisorLive(s SupervisorState) bool {
	return s.BootID != "" && s.BootID == bootID() && s.Controller.PID > 1 && processAlive(s.Controller)
}
func processAlive(p Proc) bool {
	if !sameProc(p) {
		return false
	}
	b, e := os.ReadFile(fmt.Sprintf("/proc/%d/stat", p.PID))
	if e != nil {
		return false
	}
	for i := len(b) - 1; i >= 0; i-- {
		if b[i] == ')' && i+2 < len(b) {
			return b[i+2] != 'Z' && b[i+2] != 'X'
		}
	}
	return false
}
func getStatus(l Layout) LiveStatus {
	p := processStatus(l)
	result := LiveStatus{Status: p, Revision: packageRevision, Phase: "stopped", OnlineSource: "not_available", CheckedAt: time.Now().UTC().Format(time.RFC3339)}
	unknown := func() LiveStatus {
		result.Running = false
		result.Ready = false
		result.Phase = "unknown"
		result.Online = nil
		result.OnlineSource = "state_unreadable"
		result.Note = "当前进程状态无法可靠读取，业务在线未确认。"
		return result
	}
	clientState, stateErr := loadState(l)
	if stateErr != nil && !os.IsNotExist(stateErr) {
		return unknown()
	}
	supervisor, supervisorErr := loadSupervisor(l)
	if supervisorErr != nil && !os.IsNotExist(supervisorErr) {
		return unknown()
	}
	if stateErr == nil {
		if bootID() == "" {
			return unknown()
		}
		if clientState.BootID == bootID() && clientState.Client.PID > 1 {
			if _, procErr := proc(clientState.Client.PID); procErr != nil && !os.IsNotExist(procErr) {
				return unknown()
			}
		}
	}
	if s, e := loadState(l); e == nil && p.Running && !processAlive(s.Client) {
		result.Running = false
		result.Ready = false
	}
	if s, e := supervisor, supervisorErr; e == nil && supervisorLive(s) {
		result.ControllerRunning = true
		result.Phase = s.Phase
		result.AutomaticRestarts = s.AutomaticRestarts
		result.ManualRestarts = s.ManualRestarts
		result.LastExit = s.LastExit
		result.NextRetry = s.NextRetry
		if result.Running && s.Phase == "starting" {
			result.Phase = "running"
		}
	}
	// No authenticated business-online API has been verified for this client.
	// A listening socket, successful TCP connection, or old log is never online=true.
	if !result.Running {
		offline := false
		result.Online = &offline
		result.OnlineSource = "process_absent"
	}
	result.Note = "业务在线未确认：未取得已验证的供应商在线状态接口。进程与端口状态均来自当前系统检查。"
	return result
}
func backoff(failures int) time.Duration {
	if failures < 1 {
		failures = 1
	}
	if failures > 6 {
		return 30 * time.Second
	}
	d := time.Second * time.Duration(1<<uint(failures-1))
	if d > 30*time.Second {
		return 30 * time.Second
	}
	return d
}
func recentFailures(times []time.Time, now time.Time) []time.Time {
	out := times[:0]
	for _, t := range times {
		if now.Sub(t) < time.Minute {
			out = append(out, t)
		}
	}
	return out
}

type controlServer struct {
	server   *http.Server
	listener *net.UnixListener
	requests chan struct{}
	pending  atomic.Bool
}

func controlPath(l Layout) string {
	if sockets := os.Getenv("ONEKVM_EXTENSION_SOCKET"); sockets != "" {
		return filepath.Join(sockets, "nodebaby-control.sock")
	}
	// Standalone/test fallback only. The real host supplies a writable runtime
	// socket directory even when persistent data uses a different filesystem.
	return filepath.Join(l.Data, "control.sock")
}

type peerKey struct{}

func startControl(l Layout) (*controlServer, error) {
	p := controlPath(l)
	if parent, e := os.Lstat(filepath.Dir(p)); e != nil || !parent.IsDir() || parent.Mode()&os.ModeSymlink != 0 {
		return nil, errors.New("invalid runtime socket directory")
	}
	if st, e := os.Lstat(p); e == nil {
		if st.Mode()&os.ModeSocket == 0 {
			return nil, errors.New("control path is not a socket")
		}
		if e = os.Remove(p); e != nil {
			return nil, e
		}
	} else if !os.IsNotExist(e) {
		return nil, e
	}
	listener, e := net.ListenUnix("unix", &net.UnixAddr{Name: p, Net: "unix"})
	if e != nil {
		return nil, e
	}
	if e = os.Chmod(p, 0600); e != nil {
		listener.Close()
		return nil, e
	}
	c := &controlServer{listener: listener, requests: make(chan struct{}, 1)}
	ownExe, _ := os.Executable()
	c.server = &http.Server{ReadHeaderTimeout: time.Second, ReadTimeout: 2 * time.Second, WriteTimeout: 2 * time.Second, IdleTimeout: 2 * time.Second, MaxHeaderBytes: 4096,
		ConnContext: func(ctx context.Context, conn net.Conn) context.Context {
			authorized := false
			if unix, ok := conn.(*net.UnixConn); ok {
				if raw, e := unix.SyscallConn(); e == nil {
					_ = raw.Control(func(fd uintptr) {
						if u, e := syscall.GetsockoptUcred(int(fd), syscall.SOL_SOCKET, syscall.SO_PEERCRED); e == nil && int(u.Uid) == os.Geteuid() {
							exe, e := os.Readlink(fmt.Sprintf("/proc/%d/exe", u.Pid))
							authorized = e == nil && exe == ownExe
						}
					})
				}
			}
			return context.WithValue(ctx, peerKey{}, authorized)
		},
		Handler: http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			if r.Context().Value(peerKey{}) != true {
				http.Error(w, "forbidden", 403)
				return
			}
			if r.Method == "GET" && r.URL.Path == "/logs" && r.URL.RawQuery == "" {
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(readLogsInNamespace(l, true))
				return
			}
			if r.Method != "POST" || r.URL.Path != "/restart" || r.URL.RawQuery != "" {
				http.Error(w, "unsupported request", 400)
				return
			}
			body, e := io.ReadAll(io.LimitReader(r.Body, 2))
			if e != nil || len(body) != 0 {
				http.Error(w, "empty body required", 400)
				return
			}
			if !c.pending.CompareAndSwap(false, true) {
				http.Error(w, "restart pending", 409)
				return
			}
			c.requests <- struct{}{}
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(map[string]any{"accepted": true})
		}),
	}
	go func() { _ = c.server.Serve(listener) }()
	return c, nil
}
func (c *controlServer) close() { _ = c.server.Close(); _ = c.listener.Close() }
func requestRestart(l Layout) (any, error) {
	cfg, e := loadSettings(l.Config)
	if e != nil || !cfg.ServiceEnabled {
		return nil, errors.New("client is disabled; restart will not enable it")
	}
	s, e := loadSupervisor(l)
	if e != nil || !supervisorLive(s) {
		return nil, errors.New("supervisor is not running; use OneKVM service start")
	}
	tr := &http.Transport{Proxy: nil, DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
		return (&net.Dialer{Timeout: time.Second}).DialContext(ctx, "unix", controlPath(l))
	}, DisableKeepAlives: true, MaxResponseHeaderBytes: 4096}
	defer tr.CloseIdleConnections()
	client := &http.Client{Transport: tr, Timeout: 2 * time.Second}
	r, e := client.Post("http://unix/restart", "application/json", nil)
	if e != nil {
		return nil, errors.New("supervisor control unavailable")
	}
	defer r.Body.Close()
	if r.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("restart rejected (%d)", r.StatusCode)
	}
	var result struct {
		Accepted bool `json:"accepted"`
	}
	if e = json.NewDecoder(io.LimitReader(r.Body, 1024)).Decode(&result); e != nil || !result.Accepted {
		return nil, errors.New("invalid supervisor response")
	}
	return result, nil
}
func requestLogs(l Layout) (LogResponse, error) {
	s, e := loadSupervisor(l)
	if e != nil || !supervisorLive(s) {
		return LogResponse{}, errors.New("supervisor is not running")
	}
	tr := &http.Transport{Proxy: nil, DialContext: func(ctx context.Context, _, _ string) (net.Conn, error) {
		return (&net.Dialer{Timeout: time.Second}).DialContext(ctx, "unix", controlPath(l))
	}, DisableKeepAlives: true, MaxResponseHeaderBytes: 4096}
	defer tr.CloseIdleConnections()
	client := &http.Client{Transport: tr, Timeout: 2 * time.Second}
	r, e := client.Get("http://unix/logs")
	if e != nil {
		return LogResponse{}, e
	}
	defer r.Body.Close()
	if r.StatusCode != 200 {
		return LogResponse{}, errors.New("service log query rejected")
	}
	var result LogResponse
	e = json.NewDecoder(io.LimitReader(r.Body, 128<<10)).Decode(&result)
	if e != nil || !result.Redacted || len(result.Entries) > 100 {
		return LogResponse{}, errors.New("invalid service log response")
	}
	return result, nil
}

func service(ctx context.Context, l Layout) (result error) {
	cfg, e := loadSettings(l.Config)
	if e != nil {
		return e
	}
	if !cfg.ServiceEnabled {
		return errors.New("service is disabled")
	}
	if e = verifyPayload(l); e != nil {
		return e
	}
	if e = privateDir(l.Data); e != nil {
		return e
	}
	fd, e := syscall.Open(filepath.Join(l.Data, "service.lock"), syscall.O_CREAT|syscall.O_RDWR|syscall.O_NOFOLLOW|syscall.O_CLOEXEC, 0600)
	if e != nil {
		return e
	}
	defer syscall.Close(fd)
	if e = syscall.Flock(fd, syscall.LOCK_EX|syscall.LOCK_NB); e != nil {
		return errors.New("another nodebaby controller holds the lock")
	}
	defer syscall.Flock(fd, syscall.LOCK_UN)
	if _, _, errno := syscall.Syscall6(syscall.SYS_PRCTL, 36, 1, 0, 0, 0, 0); errno != 0 {
		return fmt.Errorf("subreaper: %v", errno)
	}
	control, e := startControl(l)
	if e != nil {
		return e
	}
	defer control.close()
	self, e := proc(os.Getpid())
	if e != nil {
		return e
	}
	state := SupervisorState{BootID: bootID(), Controller: self, Phase: "starting"}
	save := func() error {
		state.Updated = time.Now().UTC().Format(time.RFC3339)
		return atomicJSON(supervisorPath(l), state)
	}
	defer func() {
		os.Remove(supervisorPath(l))
		event(l, "客户端监管已停止。")
		recordEvent(l, "SUPERVISOR_STOPPED")
	}()
	var cancel context.CancelFunc
	var done chan error
	launch := func() error {
		state.Phase = "starting"
		state.NextRetry = ""
		state.Attempts++
		if e := save(); e != nil {
			return e
		}
		childCtx, c := context.WithCancel(ctx)
		cancel = c
		done = make(chan error, 1)
		go func() { done <- runOnce(childCtx, l) }()
		recordEvent(l, "CLIENT_STARTED")
		return nil
	}
	finish := func() error {
		if cancel != nil {
			cancel()
			err := <-done
			cancel = nil
			done = nil
			return err
		}
		return nil
	}
	defer func() { _ = finish() }()
	if e = launch(); e != nil {
		return e
	}
	failures := []time.Time{}
	var retry *time.Timer
	var retryC <-chan time.Time
	stopRetry := func() {
		if retry != nil {
			retry.Stop()
		}
		retryC = nil
	}
	defer stopRetry()
	for {
		select {
		case <-ctx.Done():
			return nil
		case <-control.requests:
			stopRetry()
			recordEvent(l, "RESTART_REQUESTED")
			state.Phase = "restarting"
			if e = save(); e != nil {
				return e
			}
			_ = finish()
			if ctx.Err() != nil {
				return nil
			}
			// A new client is forbidden until all previous descendants are gone.
			if cleanupErr := stopChildren(os.Getpid(), 2*time.Second); cleanupErr != nil {
				state.Phase = "failed"
				state.LastExit = "cleanup_failed"
				state.NextRetry = ""
				recordEvent(l, "CLEANUP_FAILED")
				control.pending.Store(false)
				if e = save(); e != nil {
					return e
				}
				continue
			}
			failures = nil
			state.ManualRestarts++
			state.LastExit = ""
			e = launch()
			control.pending.Store(false)
			if e != nil {
				return e
			}
		case <-retryC:
			retryC = nil
			if ctx.Err() != nil {
				return nil
			}
			state.AutomaticRestarts++
			if e = launch(); e != nil {
				return e
			}
		case childError := <-done:
			cancel()
			cancel = nil
			done = nil
			if ctx.Err() != nil {
				return nil
			}
			if errors.Is(childError, errUnreaped) {
				state.Phase = "failed"
				state.LastExit = "cleanup_failed"
				state.NextRetry = ""
				recordEvent(l, "CLEANUP_FAILED")
				if e = save(); e != nil {
					return e
				}
				continue
			}
			recordEvent(l, "UNEXPECTED_EXIT")
			state.LastExit = "unexpected_exit"
			now := time.Now()
			failures = append(recentFailures(failures, now), now)
			if len(failures) >= 5 {
				state.Phase = "failed"
				state.NextRetry = ""
				recordEvent(l, "CRASH_LOOP")
			} else {
				delay := backoff(len(failures))
				state.Phase = "backoff"
				state.NextRetry = now.Add(delay).UTC().Format(time.RFC3339)
				retry = time.NewTimer(delay)
				retryC = retry.C
				recordEvent(l, "AUTO_RETRY")
			}
			if e = save(); e != nil {
				return e
			}
		}
	}
}
