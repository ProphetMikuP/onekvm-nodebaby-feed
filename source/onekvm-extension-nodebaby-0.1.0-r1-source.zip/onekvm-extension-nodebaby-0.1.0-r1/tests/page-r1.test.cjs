// SPDX-License-Identifier: MIT
const fs = require('node:fs'), vm = require('node:vm'), assert = require('node:assert/strict')
const path = require('node:path')
const code = fs.readFileSync(path.join(__dirname, '../web/page.js'), 'utf8')
let component, mounted, unmount, settings, nextTimer = 0
const timers = new Map(), buttons = [], calls = [], doc = { visibilityState: 'visible' }
let current = { running: false, ready: false, controllerRunning: false, online: false, phase: 'stopped' }, fail = false
const h = (type, props, children) => {
  const node = { type, props, children }
  if (type === 'button' && props?.onClick) buttons.push(node)
  return node
}
const runtime = {
  vue: { defineComponent: v => v, h, ref: value => ({ value }), computed: fn => ({ get value() { return fn() } }),
    onMounted: fn => { mounted = fn }, onBeforeUnmount: fn => { unmount = fn } },
  naive: { NAlert: 'alert', NButton: 'button', NInputNumber: 'number', NSwitch: 'switch', NTag: 'tag', NModal: 'modal' },
  register(id, descriptor) { assert.equal(id, 'nodebaby'); component = descriptor.component },
}
vm.runInNewContext(code, { window: { OneKVMPluginUI: { v1: runtime } }, document: doc, Date,
  setTimeout: (fn, ms) => { assert.equal(ms, 5000); timers.set(++nextTimer, fn); return nextTimer }, clearTimeout: id => timers.delete(id) })
const host = {
  extension: { value: { settings: { service_enabled: false, port: 9118 } } },
  registerSettings(spec) { settings = spec; return () => {} },
  async invoke(name) { calls.push(name); if (name === 'status') { if (fail) throw Error('unavailable'); return { ...current } }
    if (name === 'restart') return { accepted: true }
    if (name === 'logs') return { entries: [{ time: '2026-11-23T12:00:00Z', source: 'controller', message: '已发起客户端启动。' }], hiddenLines: 3 }
    throw Error('unexpected method ' + name)
  },
  async saveSettings() { throw Error('No implicit settings write expected') },
}
const render = component.setup({ host })
function text(node) {
  if (node == null) return ''
  if (typeof node === 'string') return node
  if (Array.isArray(node)) return node.map(text).join(' ')
  return (typeof node.props === 'string' || Array.isArray(node.props) ? text(node.props) : '') + text(node.children?.default ? node.children.default() : node.children)
}
function draw() { buttons.length = 0; return render() }
function button(label) { draw(); const b = buttons.find(x => x.children.default() === label); assert.ok(b, label); return b }
async function tick() { const item = timers.entries().next().value; assert.ok(item); timers.delete(item[0]); await item[1]() }
;(async () => {
  await mounted(); assert.deepEqual(calls, ['status']); assert.equal(settings.collect().service_enabled, false)
  assert.equal(button('一键重启').props.disabled, true); assert.equal(button('获取官方绑定链接').props.disabled, true)
  assert.match(text(draw()), /未在线（客户端未运行）/)
  current = { running: true, ready: true, controllerRunning: true, online: null, phase: 'running', manualRestarts: 0 }
  await tick(); assert.match(text(draw()), /业务在线：未确认/); assert.equal(button('一键重启').props.disabled, false)
  const before = JSON.stringify(settings.collect()); await button('一键重启').props.onClick()
  assert.equal(JSON.stringify(settings.collect()), before); assert.equal(calls.includes('restart'), true)
  assert.match(text(draw()), /已请求重启/); assert.doesNotMatch(text(draw()), /客户端进程已重新启动/)
  current.manualRestarts = 1; await tick(); assert.match(text(draw()), /客户端进程已重新启动/)
  await button('查看日志').props.onClick(); assert.match(text(draw()), /已隐藏 3 行/)
  fail = true; await tick(); assert.match(text(draw()), /状态未更新，暂无法确认/); assert.equal(button('一键重启').props.disabled, true)
  fail = false; await tick(); assert.doesNotMatch(text(draw()), /状态更新失败：/)
  doc.visibilityState = 'hidden'; const count = calls.length; await tick(); assert.equal(calls.length, count)
  unmount(); assert.equal(timers.size, 0); assert.equal(code.includes('innerHTML'), false)
  console.log('PASS: live polling, unknown-online semantics, stale status, restart acknowledgement vs completion, redacted log dialog, hidden pause, unmount cleanup, no implicit enable.')
})().catch(e => { console.error(e); process.exitCode = 1 })
