#!/usr/bin/env python3
"""Prepare an EMPTY local test root; never use a device root filesystem.
Requires the reference ARM64 musl and libgcc from a local test environment.
"""
import argparse,io,shutil,tarfile
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from verify_ipk import members,verify
p=argparse.ArgumentParser();p.add_argument('--ipk',type=Path,required=True);p.add_argument('--root',type=Path,required=True);p.add_argument('--reference',type=Path,required=True);p.add_argument('--native-controller',type=Path,required=True);a=p.parse_args()
verify(a.ipk)
a.root.mkdir(parents=True,exist_ok=True)
if any(a.root.iterdir()):raise SystemExit('Test root must be empty; refusing to overwrite existing files.')
for name in ['bin','lib','usr/lib','proc','dev','tmp','data/onekvm/app-data/nodebaby','run/onekvm/extensions/nodebaby/sockets']:(a.root/name).mkdir(parents=True,exist_ok=True)
shutil.copyfile('/usr/bin/qemu-aarch64-static',a.root/'bin/qemu-aarch64-static');(a.root/'bin/qemu-aarch64-static').chmod(0o755)
for name in ['lib/ld-musl-aarch64.so.1','usr/lib/libgcc_s.so.1']:shutil.copyfile(a.reference/name,a.root/name)
(a.root/'lib/libc.musl-aarch64.so.1').symlink_to('ld-musl-aarch64.so.1')
with tarfile.open(fileobj=io.BytesIO(members(a.ipk.read_bytes())['data.tar.gz']),mode='r:gz') as tar:
 for e in tar:
  assert e.isfile() and e.name.startswith('data/onekvm/apps/nodebaby/0.1.0/') and '..' not in Path(e.name).parts
  dest=a.root/e.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(tar.extractfile(e).read());dest.chmod(e.mode)
target=a.root/'data/onekvm/apps/nodebaby/0.1.0/bin/native-controller';shutil.copyfile(a.native_controller,target);target.chmod(0o755)
for name in ['null','urandom']:(a.root/'dev'/name).touch()
(a.root/'run/onekvm/extensions/nodebaby/config.json').write_text('{"service_enabled":false,"port":19118}')
