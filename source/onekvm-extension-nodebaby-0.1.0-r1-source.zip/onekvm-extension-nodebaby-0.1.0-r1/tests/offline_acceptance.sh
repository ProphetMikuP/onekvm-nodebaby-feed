#!/bin/bash
# Destructive only to processes inside a NEW local PID/net/user namespace.
# Must be called with a disposable root prepared by offline_prepare.py.
set -euo pipefail
ROOTFS=$(readlink -f "$1")
if [ "${2:-}" != --inside ]; then
 test -f "$ROOTFS/data/onekvm/apps/nodebaby/0.1.0/bin/native-controller"
 exec timeout -s KILL 65 unshare --user --map-root-user --mount --pid --net --fork --kill-child bash "$0" "$ROOTFS" --inside
fi
ulimit -n 1024
mount --make-rprivate /
mount -t proc proc /proc
mount --bind /proc "$ROOTFS/proc"
mount --bind /dev/null "$ROOTFS/dev/null"
mount --bind /dev/urandom "$ROOTFS/dev/urandom"
mount -t tmpfs -o size=1m,mode=700 tmpfs "$ROOTFS/run/onekvm/extensions/nodebaby/sockets"
export ONEKVM_EXTENSION_SOCKET=/run/onekvm/extensions/nodebaby/sockets
export ONEKVM_EXTENSION_ID=nodebaby
ARM=/data/onekvm/apps/nodebaby/0.1.0/bin/onekvm-nodebaby-controller
NATIVE=/data/onekvm/apps/nodebaby/0.1.0/bin/native-controller
chroot "$ROOTFS" /bin/qemu-aarch64-static "$ARM" --health
chroot "$ROOTFS" /bin/qemu-aarch64-static "$ARM" status
printf '%s\n' '{"service_enabled":true,"port":19118}' > "$ROOTFS/run/onekvm/extensions/nodebaby/config.json"
chroot "$ROOTFS" "$NATIVE" > "$ROOTFS/tmp/wrapper-output" 2>&1 &
wrapper=$!
wait_status() {
 local condition="$1"
 for i in $(seq 1 100); do
  chroot "$ROOTFS" "$NATIVE" status > "$ROOTFS/tmp/latest-status.json"
  if python3 - "$ROOTFS/tmp/latest-status.json" "$condition" <<'PY'
import json,sys
s=json.load(open(sys.argv[1]));mode=sys.argv[2]
assert s['online'] is None if s['running'] else s['online'] is False
ready=s['running'] and s['ready']
ok=ready if mode=='ready' else ready and s['manualRestarts']>=1 if mode=='manual' else ready and s['automaticRestarts']>=1
sys.exit(0 if ok else 1)
PY
  then cat "$ROOTFS/tmp/latest-status.json"; return 0; fi
  sleep 0.15
 done
 cat "$ROOTFS/tmp/wrapper-output"; return 1
}
wait_status ready
old=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["client"]["PID"])' "$ROOTFS/data/onekvm/app-data/nodebaby/state.json")
chroot "$ROOTFS" "$NATIVE" restart
wait_status manual
new=$(python3 -c 'import json,sys; print(json.load(open(sys.argv[1]))["client"]["PID"])' "$ROOTFS/data/onekvm/app-data/nodebaby/state.json")
test "$old" != "$new"
# Explicitly crash ONLY the temporary client inside this isolated PID namespace.
kill -KILL "$new"
wait_status auto
chroot "$ROOTFS" "$NATIVE" logs > "$ROOTFS/tmp/latest-logs.json"
cat "$ROOTFS/tmp/latest-logs.json"
python3 - "$ROOTFS/tmp/latest-logs.json" <<'PY'
import json,sys
logs=json.load(open(sys.argv[1]))
assert logs['serviceLogsAvailable'] and logs['redacted']
assert any(e['source']=='client' for e in logs['entries']), 'client diagnostics not read from service PrivateTmp'
PY
kill -TERM "$wrapper"
wait "$wrapper"
chroot "$ROOTFS" "$NATIVE" status
ps -eo pid,ppid,comm
python3 - <<'PY'
import os
remaining=[int(p) for p in os.listdir('/proc') if p.isdigit() and int(p) not in (1,os.getpid())]
assert not remaining, f'residual namespace processes: {remaining}'
PY
echo 'PASS: same-source native supervisor with actual ARM64 client: manual restart, abnormal-exit recovery, scoped stop. No Internet, TUN or device test.'
