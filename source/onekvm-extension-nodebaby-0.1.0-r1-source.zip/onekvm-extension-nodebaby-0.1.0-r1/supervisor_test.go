// SPDX-License-Identifier: MIT
package main

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func setFake(t *testing.T, l Layout, script string) {
	t.Helper()
	b := []byte("#!/bin/sh\n" + script + "\n")
	p := filepath.Join(l.Root, "runtime/owjdxb/bin/owjdxb")
	if e := os.WriteFile(p, b, 0700); e != nil {
		t.Fatal(e)
	}
	files, e := readIndex(l)
	if e != nil {
		t.Fatal(e)
	}
	sum := sha256.Sum256(b)
	for i := range files {
		if files[i].Path == "bin/owjdxb" {
			files[i].SHA256 = hex.EncodeToString(sum[:])
		}
	}
	if e = atomicJSON(filepath.Join(l.Root, "runtime-index.json"), files); e != nil {
		t.Fatal(e)
	}
}

type testService struct {
	cmd  *exec.Cmd
	l    Layout
	done chan error
}

func startFixture(t *testing.T, l Layout) *testService {
	t.Helper()
	exe, _ := os.Executable()
	b, _ := json.Marshal(l)
	cmd := exec.Command(exe, "-test.run=^TestServiceHelper$", "-test.v")
	cmd.Env = append(os.Environ(), "NB_SERVICE_TEST=1", "NB_LAYOUT="+string(b))
	log, e := os.Create(filepath.Join(l.Data, "test-helper.log"))
	if e != nil {
		t.Fatal(e)
	}
	cmd.Stdout = log
	cmd.Stderr = log
	if e = cmd.Start(); e != nil {
		t.Fatal(e)
	}
	s := &testService{cmd, l, make(chan error, 1)}
	go func() { s.done <- cmd.Wait(); log.Close() }()
	t.Cleanup(func() {
		os.WriteFile(filepath.Join(l.Data, "cancel"), []byte("stop"), 0600)
		select {
		case <-s.done:
		case <-time.After(6 * time.Second):
			cmd.Process.Kill()
			<-s.done
		}
	})
	return s
}
func awaitStatus(t *testing.T, l Layout, timeout time.Duration, check func(LiveStatus) bool) LiveStatus {
	t.Helper()
	deadline := time.Now().Add(timeout)
	for {
		st := getStatus(l)
		if check(st) {
			return st
		}
		if time.Now().After(deadline) {
			b, _ := os.ReadFile(filepath.Join(l.Data, "test-helper.log"))
			t.Fatalf("status timeout: %+v; helper: %s", st, b)
		}
		time.Sleep(40 * time.Millisecond)
	}
}

const waitScript = "trap 'exit 0' TERM\nsleep 90 &\nwait"

func TestRecoveryAfterAbnormalExit(t *testing.T) {
	l := fixture(t)
	setFake(t, l, "if [ ! -f \"$HOME/first\" ]; then touch \"$HOME/first\"; setsid sh -c 'sleep 90' & sleep 0.1; exit 9; fi\n"+waitScript)
	startFixture(t, l)
	st := awaitStatus(t, l, 12*time.Second, func(s LiveStatus) bool { return s.Running && s.AutomaticRestarts >= 1 })
	if st.Online != nil {
		t.Fatal("running process was treated as business online")
	}
	if st.LastExit != "unexpected_exit" {
		t.Fatal(st)
	}
}
func TestRecoveryAfterUnexpectedCleanExit(t *testing.T) {
	l := fixture(t)
	setFake(t, l, "if [ ! -f \"$HOME/first\" ]; then touch \"$HOME/first\"; exit 0; fi\n"+waitScript)
	startFixture(t, l)
	awaitStatus(t, l, 8*time.Second, func(s LiveStatus) bool { return s.Running && s.AutomaticRestarts == 1 })
}
func TestManualRestartReplacesProcess(t *testing.T) {
	l := fixture(t)
	setFake(t, l, waitScript)
	startFixture(t, l)
	awaitStatus(t, l, 5*time.Second, func(s LiveStatus) bool { return s.Running })
	old, _ := loadState(l)
	if _, e := requestRestart(l); e != nil {
		t.Fatal(e)
	}
	awaitStatus(t, l, 8*time.Second, func(s LiveStatus) bool { return s.Running && s.ManualRestarts == 1 })
	current, _ := loadState(l)
	if current.Client.PID == old.Client.PID && current.Client.Start == old.Client.Start {
		t.Fatal("old client retained")
	}
	if processAlive(old.Client) {
		t.Fatal("old process remained")
	}
}
func TestCrashLoopPausesAndManualRepair(t *testing.T) {
	l := fixture(t)
	setFake(t, l, "if [ ! -f \"$HOME/repaired\" ]; then exit 7; fi\n"+waitScript)
	startFixture(t, l)
	st := awaitStatus(t, l, 28*time.Second, func(s LiveStatus) bool { return s.Phase == "failed" })
	if st.Running || !st.ControllerRunning || st.NextRetry != "" {
		t.Fatal(st)
	}
	if e := os.WriteFile(filepath.Join(l.Data, "repaired"), nil, 0600); e != nil {
		t.Fatal(e)
	}
	if _, e := requestRestart(l); e != nil {
		t.Fatal(e)
	}
	awaitStatus(t, l, 8*time.Second, func(s LiveStatus) bool { return s.Running && s.ManualRestarts == 1 })
}
func TestStopDuringBackoffDoesNotRelaunch(t *testing.T) {
	l := fixture(t)
	setFake(t, l, "echo attempt >> \"$HOME/attempts\"\nexit 3")
	s := startFixture(t, l)
	awaitStatus(t, l, 5*time.Second, func(s LiveStatus) bool { return s.Phase == "backoff" })
	os.WriteFile(filepath.Join(l.Data, "cancel"), nil, 0600)
	awaitStatus(t, l, 5*time.Second, func(s LiveStatus) bool { return !s.ControllerRunning })
	b := mustRead(t, filepath.Join(l.Data, "attempts"))
	if strings.Count(string(b), "attempt") != 1 {
		t.Fatal("relaunched after stop")
	}
	_ = s
}
func TestRestartCannotEnableDisabledClient(t *testing.T) {
	l := fixture(t)
	if e := atomicJSON(l.Config, Settings{false, 9118}); e != nil {
		t.Fatal(e)
	}
	if _, e := requestRestart(l); e == nil {
		t.Fatal("disabled restart accepted")
	}
	if _, e := os.Stat(filepath.Join(l.Data, "state.json")); !os.IsNotExist(e) {
		t.Fatal("client state unexpectedly created")
	}
}
func TestStoppedStatusIsOfflineNotOnline(t *testing.T) {
	st := getStatus(fixture(t))
	if st.Online == nil || *st.Online || st.Running || st.ControllerRunning {
		t.Fatal(st)
	}
}
func TestRetryPolicy(t *testing.T) {
	for i, want := range []time.Duration{time.Second, 2 * time.Second, 4 * time.Second, 8 * time.Second, 16 * time.Second, 30 * time.Second, 30 * time.Second} {
		if got := backoff(i + 1); got != want {
			t.Fatal(i, got, want)
		}
	}
	now := time.Now()
	times := []time.Time{now.Add(-61 * time.Second), now.Add(-time.Second)}
	if len(recentFailures(times, now)) != 1 {
		t.Fatal("failure window")
	}
}
func TestUnreadableStateIsUnknown(t *testing.T) {
	l := fixture(t)
	os.WriteFile(filepath.Join(l.Data, "state.json"), []byte("invalid-json"), 0600)
	st := getStatus(l)
	if st.Phase != "unknown" || st.Online != nil {
		t.Fatal("unreadable record was reported offline", st)
	}
	os.Remove(filepath.Join(l.Data, "state.json"))
	os.WriteFile(supervisorPath(l), []byte("bad-json"), 0600)
	st = getStatus(l)
	if st.Phase != "unknown" || st.Online != nil {
		t.Fatal(st)
	}
}
func TestHostRuntimeSocketPath(t *testing.T) {
	t.Setenv("ONEKVM_EXTENSION_SOCKET", t.TempDir())
	l := fixture(t)
	if filepath.Dir(controlPath(l)) != os.Getenv("ONEKVM_EXTENSION_SOCKET") {
		t.Fatal("host socket path ignored")
	}
}
func TestServiceLogQueryIsReadOnlyAndRedacted(t *testing.T) {
	l := fixture(t)
	setFake(t, l, "echo 'Network unreachable token=SECRET_FROM_CLIENT'\n"+waitScript)
	startFixture(t, l)
	awaitStatus(t, l, 5*time.Second, func(s LiveStatus) bool { return s.Running })
	var response LogResponse
	deadline := time.Now().Add(3 * time.Second)
	for {
		var e error
		response, e = requestLogs(l)
		if e == nil && response.ServiceLogsAvailable {
			found := false
			for _, entry := range response.Entries {
				if entry.Code == "NETWORK_UNREACHABLE" {
					found = true
				}
			}
			if found {
				break
			}
		}
		if time.Now().After(deadline) {
			t.Fatal("service logs unavailable", e, response)
		}
		time.Sleep(40 * time.Millisecond)
	}
	b, _ := json.Marshal(response)
	if strings.Contains(string(b), "SECRET") {
		t.Fatal("secret exposed")
	}
	if getStatus(l).ManualRestarts != 0 {
		t.Fatal("log query restarted client")
	}
}
func TestRestartSocketRejectsOtherExecutable(t *testing.T) {
	l := fixture(t)
	setFake(t, l, waitScript)
	startFixture(t, l)
	awaitStatus(t, l, 5*time.Second, func(s LiveStatus) bool { return s.Running })
	script := "import socket,sys; s=socket.socket(socket.AF_UNIX); s.connect(sys.argv[1]); s.sendall(b'POST /restart HTTP/1.0\\r\\nContent-Length: 0\\r\\n\\r\\n'); print(s.recv(4096).decode())"
	b, e := exec.Command("python3", "-c", script, controlPath(l)).CombinedOutput()
	if e != nil {
		t.Fatal(e, string(b))
	}
	if !strings.Contains(string(b), "403") {
		t.Fatal("unrelated executable accepted", string(b))
	}
	st := getStatus(l)
	if st.ManualRestarts != 0 {
		t.Fatal("unauthorized restart occurred")
	}
}
