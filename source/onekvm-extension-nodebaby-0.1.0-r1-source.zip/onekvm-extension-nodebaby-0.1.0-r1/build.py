#!/usr/bin/env python3
"""Reproducible, dependency-free IPK packager; never runs vendor code.

Use Go >=1.24 on Linux. CGO is disabled; no target SDK or system-library
replacement is necessary. The original client archive remains unmodified.
"""
import argparse
import gzip
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import shutil
import struct
import subprocess
import tarfile

BASE = Path(__file__).resolve().parent
CLIENT_NAME = 'owjdxb_linux_muslarm64_4.3.5-731.tgz'
CLIENT_SHA256 = '16749ee14a6b4e4a7f09a01b4b4955bb05c89b099ad369cc0067fc3e1d82cd3a'
CLIENT_URL = 'https://cdn.ionewu.com/upgrade/jdxb/' + CLIENT_NAME
VERSION = '0.1.0'
REVISION = 'r1'
EPOCH = 1795392000
BINARIES = {'bin/owjdxb', 'ownbsv/ownbsvman', 'ownbsv/NodeBabyLinkService', 'owjdgj/owjdgjman'}
VERSIONS = {'bin/.version', 'ownbsv/.version', 'owjdgj/.version'}
SHA = lambda b: hashlib.sha256(b).hexdigest()

def tgz(files):
    buffer = io.BytesIO()
    with tarfile.open(fileobj=buffer, mode='w', format=tarfile.USTAR_FORMAT) as tar:
        for name, data, mode in sorted(files):
            item = tarfile.TarInfo(name)
            item.size, item.mode, item.mtime = len(data), mode, EPOCH
            item.uid = item.gid = 0
            item.uname = item.gname = 'root'
            tar.addfile(item, io.BytesIO(data))
    return gzip.compress(buffer.getvalue(), compresslevel=9, mtime=0)

def ar(files):
    output = bytearray(b'!<arch>\n')
    for name, data in files:
        header = f'{name + "/":<16}{EPOCH:<12}{0:<6}{0:<6}{"100644":<8}{len(data):<10}`\n'.encode()
        assert len(header) == 60
        output.extend(header); output.extend(data)
        if len(data) % 2: output.extend(b'\n')
    return bytes(output)

def elf_info(b):
    if b[:6] != b'\x7fELF\x02\x01': raise ValueError('expected ELF64 little-endian')
    machine = struct.unpack_from('<H', b, 18)[0]
    if machine != 183: raise ValueError(f'not AArch64: {machine}')
    phoff = struct.unpack_from('<Q', b, 32)[0]
    entsize, count = struct.unpack_from('<HH', b, 54)
    loads, dynamic, interp = [], None, ''
    for i in range(count):
        ptype, flags, off, vaddr, _, size, memsize, align = struct.unpack_from('<IIQQQQQQ', b, phoff + i*entsize)
        if ptype == 1: loads.append((vaddr, off, size))
        if ptype == 2: dynamic = (off, size)
        if ptype == 3: interp = b[off:off+size].rstrip(b'\0').decode()
    needed, straddr = [], None
    if dynamic:
        off, size = dynamic
        for pos in range(off, off+size, 16):
            tag, val = struct.unpack_from('<qQ', b, pos)
            if tag == 0: break
            if tag == 1: needed.append(val)
            if tag == 5: straddr = val
    names = []
    if needed:
        start = next(off+straddr-addr for addr,off,size in loads if addr <= straddr < addr+size)
        for n in needed:
            pos = start+n; names.append(b[pos:b.index(b'\0',pos)].decode())
    return {'machine':'AArch64','interpreter':interp or None,'needed':names,'sha256':SHA(b),'size':len(b)}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--client', type=Path, default=BASE/'vendor'/CLIENT_NAME)
    parser.add_argument('--go', default='go')
    parser.add_argument('--out', type=Path, default=BASE/'dist')
    parser.add_argument('--architecture', default='aarch64_cortex-a53')
    args = parser.parse_args()
    if args.architecture not in ('aarch64_cortex-a53','aarch64'):
        parser.error('choose the architecture accepted by the device opkg configuration')
    payload = args.client.read_bytes()
    if SHA(payload) != CLIENT_SHA256: raise ValueError('official client archive checksum mismatch')
    vendor, inventory = {}, {}
    with tarfile.open(fileobj=io.BytesIO(payload),mode='r:gz') as tar:
        seen = set()
        for entry in tar:
            p = PurePosixPath(entry.name)
            if entry.name.startswith('/') or '..' in p.parts or '\\' in entry.name: raise ValueError('unsafe vendor path')
            if not entry.isfile():
                if entry.isdir(): continue
                raise ValueError('vendor archive links or special files are forbidden')
            name = str(p)
            if name in seen: raise ValueError('duplicate vendor path')
            seen.add(name)
            if not name.startswith('owjdxb/'): raise ValueError('unexpected vendor root')
            relative = name[len('owjdxb/'):]
            if relative in BINARIES | VERSIONS:
                data = tar.extractfile(entry).read()
                vendor[relative] = (data, 0o755 if relative in BINARIES else 0o644)
                if relative in BINARIES: inventory[relative] = elf_info(data)
    if set(vendor) != BINARIES | VERSIONS: raise ValueError('required vendor members missing')
    for p in BINARIES - {'ownbsv/NodeBabyLinkService'}:
        assert inventory[p]['interpreter'] == '/lib/ld-musl-aarch64.so.1'
        assert sorted(inventory[p]['needed']) == ['libc.so','libgcc_s.so.1']
    assert inventory['ownbsv/NodeBabyLinkService']['needed'] == []
    # Safe replacements for the vendor scripts: no cleanup outside this runtime,
    # no killall and no --kill=yes path. The foreground supervisor owns stopping.
    for component in ('ownbsv','owjdgj'):
        script = ('#!/bin/sh\nset -eu\ncd -- "${0%/*}"\n'
                  'case "${1:-}" in\n start) shift; exec ./' + component + 'man -d "$@" ;;\n'
                  ' stop) echo "Stop through OneKVM extension host" >&2; exit 1 ;;\n'
                  ' *) echo "Unsupported operation" >&2; exit 64 ;;\nesac\n').encode()
        vendor[component+'/serv.sh'] = (script,0o755)
    index = [{'path':p,'sha256':SHA(data),'executable':bool(mode&0o111)} for p,(data,mode) in sorted(vendor.items())]
    args.out.mkdir(parents=True,exist_ok=True)
    builddir = BASE/'build'; builddir.mkdir(exist_ok=True)
    binary = builddir/'onekvm-nodebaby-controller'
    env = os.environ.copy(); env.update(GOOS='linux',GOARCH='arm64',CGO_ENABLED='0',GOTOOLCHAIN='local',GOPROXY='off',GOSUMDB='off')
    subprocess.run([args.go,'build','-trimpath','-buildvcs=false','-ldflags=-s -w -buildid=','-o',str(binary),'.'],cwd=BASE,env=env,check=True)
    controller = binary.read_bytes()
    assert elf_info(controller)['interpreter'] is None
    manifest = json.loads((BASE/'manifest.json').read_text())
    assert manifest['id']=='nodebaby' and manifest['version']==VERSION and not manifest['default_enabled']
    assert manifest['settings_schema']['properties']['service_enabled']['default'] is False
    prefix = f'data/onekvm/apps/nodebaby/{VERSION}/'
    files = [(prefix+'manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2).encode()+b'\n',0o644),
             (prefix+'bin/onekvm-nodebaby-controller',controller,0o755),
             (prefix+'runtime-index.json',json.dumps(index,indent=2).encode()+b'\n',0o644)]
    for p in ('web/page.js','web/logo.svg','LICENSE','THIRD_PARTY_NOTICES.txt'):
        files.append((prefix+p,(BASE/p).read_bytes(),0o644))
    for p,(data,mode) in sorted(vendor.items()): files.append((prefix+'runtime/owjdxb/'+p,data,mode))
    control = (f'Package: onekvm-extension-nodebaby\nVersion: {VERSION}-{REVISION}\n'
               f'Architecture: {args.architecture}\nSection: onekvm/extensions\nPriority: optional\n'
               'Maintainer: Local NodeBaby extension build\n'
               'License: MIT & Proprietary\n'
               f'X-OneKVM-Extension-Version: {VERSION}\n'
               'Depends: onekvm-extension-host, onekvm-kernel-module-tun, musl, libgcc1\n'
               f'Installed-Size: {sum(len(data) for _,data,_ in files)}\n'
               'Description: Experimental independent NodeBaby extension (disabled by default)\n').encode()
    package = ar([('debian-binary',b'2.0\n'),('control.tar.gz',tgz([('control',control,0o644)])),('data.tar.gz',tgz(files))])
    target = args.out/f'onekvm-extension-nodebaby_{VERSION}-{REVISION}_{args.architecture}.ipk'
    target.write_bytes(package)
    report = {'client_archive':{'filename':CLIENT_NAME,'url':CLIENT_URL,'sha256':CLIENT_SHA256},
              'vendor_elf':inventory,'controller_elf':elf_info(controller),
              'package':{'filename':target.name,'size':len(package),'sha256':SHA(package),'architecture':args.architecture,'paths':[p for p,_,_ in sorted(files)]},
              'go':subprocess.check_output([args.go,'version'],text=True).strip(),
              'real_device_tested':False,'upstream_client_online_tested':False}
    (args.out/'build-report.json').write_text(json.dumps(report,indent=2)+'\n')
    (args.out/'SHA256SUMS').write_text(f'{SHA(package)}  {target.name}\n')
    print(json.dumps(report['package'],indent=2))

if __name__=='__main__': main()
