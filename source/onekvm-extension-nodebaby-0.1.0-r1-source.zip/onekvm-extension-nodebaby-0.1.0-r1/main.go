// SPDX-License-Identifier: MIT
// Linux-only lifecycle wrapper. No shell interpolation or vendor stop commands.
package main

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/url"
	"os"
	"os/signal"
	"path/filepath"
	"strconv"
	"strings"
	"syscall"
	"time"
)

const version = "0.1.0"

type Settings struct {
	ServiceEnabled bool `json:"service_enabled"`
	Port           int  `json:"port"`
}
type FileSpec struct {
	Path       string `json:"path"`
	SHA256     string `json:"sha256"`
	Executable bool   `json:"executable"`
}
type Layout struct{ Root, Data, Config string }
type Proc struct {
	PID, PPID int
	Start     string
}
type State struct {
	BootID     string `json:"boot_id"`
	Controller Proc   `json:"controller"`
	Client     Proc   `json:"client"`
	Port       int    `json:"port"`
	Started    string `json:"started"`
}
type Status struct {
	Running       bool   `json:"running"`
	Port          int    `json:"port"`
	Version       string `json:"version"`
	ClientVersion string `json:"clientVersion"`
	Started       string `json:"started,omitempty"`
	Ready         bool   `json:"ready"`
	Note          string `json:"note"`
}

func envPath(key, fallback string) string {
	if p := os.Getenv(key); p != "" {
		return p
	}
	return fallback
}
func layout() (Layout, error) {
	exe, err := os.Executable()
	if err != nil {
		return Layout{}, err
	}
	root := filepath.Dir(filepath.Dir(exe))
	return Layout{root, envPath("ONEKVM_EXTENSION_DATA", "/data/onekvm/app-data/nodebaby"), filepath.Join(envPath("ONEKVM_EXTENSION_CONFIG", "/run/onekvm/extensions/nodebaby"), "config.json")}, nil
}
func loadSettings(p string) (Settings, error) {
	s := Settings{Port: 9118}
	b, e := os.ReadFile(p)
	if e != nil {
		return s, e
	}
	if len(b) > 65536 {
		return s, errors.New("settings too large")
	}
	if e = json.Unmarshal(b, &s); e != nil {
		return s, e
	}
	if s.Port < 1024 || s.Port > 65535 {
		return s, errors.New("port must be 1024..65535")
	}
	return s, nil
}
func readIndex(l Layout) ([]FileSpec, error) {
	b, e := os.ReadFile(filepath.Join(l.Root, "runtime-index.json"))
	if e != nil {
		return nil, e
	}
	var files []FileSpec
	if e = json.Unmarshal(b, &files); e != nil {
		return nil, e
	}
	if len(files) == 0 {
		return nil, errors.New("empty runtime index")
	}
	seen := map[string]bool{}
	for _, f := range files {
		clean := filepath.Clean(f.Path)
		if clean != f.Path || filepath.IsAbs(clean) || strings.HasPrefix(clean, "..") || strings.Contains(clean, "\\") || seen[clean] || len(f.SHA256) != 64 {
			return nil, errors.New("unsafe runtime index")
		}
		seen[clean] = true
	}
	for _, p := range []string{"bin/owjdxb", "ownbsv/ownbsvman", "ownbsv/NodeBabyLinkService", "owjdgj/owjdgjman"} {
		if !seen[p] {
			return nil, fmt.Errorf("required runtime missing: %s", p)
		}
	}
	return files, nil
}
func checkFile(p string, f FileSpec) error {
	st, e := os.Lstat(p)
	if e != nil {
		return e
	}
	if !st.Mode().IsRegular() {
		return fmt.Errorf("not a regular file: %s", p)
	}
	file, e := os.Open(p)
	if e != nil {
		return e
	}
	defer file.Close()
	h := sha256.New()
	if _, e = io.Copy(h, file); e != nil {
		return e
	}
	if hex.EncodeToString(h.Sum(nil)) != f.SHA256 {
		return fmt.Errorf("runtime checksum mismatch: %s", f.Path)
	}
	if f.Executable && st.Mode()&0111 == 0 {
		return fmt.Errorf("not executable: %s", f.Path)
	}
	return nil
}
func verifyPayload(l Layout) error {
	files, e := readIndex(l)
	if e != nil {
		return e
	}
	for _, f := range files {
		if e = checkFile(filepath.Join(l.Root, "runtime/owjdxb", f.Path), f); e != nil {
			return e
		}
	}
	return nil
}
func verifyRuntime(l Layout) error {
	if e := verifyPayload(l); e != nil {
		return e
	}
	// The wrapper is static; only the vendor managers use these system libraries.
	var e error
	if _, e = os.Stat("/lib/ld-musl-aarch64.so.1"); e != nil {
		return errors.New("missing /lib/ld-musl-aarch64.so.1")
	}
	found := false
	for _, p := range []string{"/lib/libgcc_s.so.1", "/usr/lib/libgcc_s.so.1"} {
		if _, e = os.Stat(p); e == nil {
			found = true
		}
	}
	if !found {
		return errors.New("missing libgcc_s.so.1 (libgcc1)")
	}
	return nil
}
func privateDir(p string) error {
	if e := os.MkdirAll(p, 0700); e != nil {
		return e
	}
	st, e := os.Lstat(p)
	if e != nil {
		return e
	}
	if !st.IsDir() || st.Mode()&os.ModeSymlink != 0 {
		return errors.New("private path is not a directory")
	}
	return os.Chmod(p, 0700)
}
func atomicJSON(p string, v any) error {
	b, e := json.Marshal(v)
	if e != nil {
		return e
	}
	f, e := os.CreateTemp(filepath.Dir(p), ".nodebaby-*")
	if e != nil {
		return e
	}
	name := f.Name()
	defer os.Remove(name)
	if e = f.Chmod(0600); e == nil {
		_, e = f.Write(append(b, '\n'))
	}
	if e == nil {
		e = f.Sync()
	}
	ce := f.Close()
	if e == nil {
		e = ce
	}
	if e != nil {
		return e
	}
	return os.Rename(name, p)
}
func materialize(l Layout) (string, error) {
	files, e := readIndex(l)
	if e != nil {
		return "", e
	}
	// A versioned private working copy permits vendor relative state writes while
	// package files and other plugins stay read-only under the host sandbox.
	base := filepath.Join(l.Data, "work", version)
	if e = privateDir(base); e != nil {
		return "", e
	}
	dst := filepath.Join(base, "owjdxb")
	if e = privateDir(dst); e != nil {
		return "", e
	}
	for _, f := range files {
		source := filepath.Join(l.Root, "runtime/owjdxb", f.Path)
		if e = checkFile(source, f); e != nil {
			return "", e
		}
		target := filepath.Join(dst, f.Path)
		if e = privateDir(filepath.Dir(target)); e != nil {
			return "", e
		}
		// Always republish authenticated package bytes before starting. No unknown
		// downloaded executable is launched by the wrapper on subsequent starts.
		in, e := os.Open(source)
		if e != nil {
			return "", e
		}
		out, e := os.CreateTemp(filepath.Dir(target), ".runtime-*")
		if e != nil {
			in.Close()
			return "", e
		}
		name := out.Name()
		_, e = io.Copy(out, in)
		in.Close()
		mode := os.FileMode(0600)
		if f.Executable {
			mode = 0700
		}
		if e == nil {
			e = out.Chmod(mode)
		}
		ce := out.Close()
		if e == nil {
			e = ce
		}
		if e == nil {
			e = os.Rename(name, target)
		}
		os.Remove(name)
		if e != nil {
			return "", e
		}
	}
	return dst, nil
}

func proc(pid int) (Proc, error) {
	b, e := os.ReadFile(fmt.Sprintf("/proc/%d/stat", pid))
	if e != nil {
		return Proc{}, e
	}
	// comm may contain spaces and parentheses; fields after the last ')' start at state.
	i := strings.LastIndexByte(string(b), ')')
	if i < 0 {
		return Proc{}, errors.New("bad proc stat")
	}
	fields := strings.Fields(string(b)[i+1:])
	if len(fields) < 20 {
		return Proc{}, errors.New("short proc stat")
	}
	ppid, e := strconv.Atoi(fields[1])
	if e != nil {
		return Proc{}, e
	}
	return Proc{pid, ppid, fields[19]}, nil
}
func sameProc(p Proc) bool { now, e := proc(p.PID); return e == nil && now.Start == p.Start }
func descendants(parent int) []Proc {
	entries, _ := os.ReadDir("/proc")
	all := []Proc{}
	for _, ent := range entries {
		pid, e := strconv.Atoi(ent.Name())
		if e != nil {
			continue
		}
		if p, e := proc(pid); e == nil {
			all = append(all, p)
		}
	}
	owned := map[int]bool{parent: true}
	out := []Proc{}
	for changed := true; changed; {
		changed = false
		for _, p := range all {
			if !owned[p.PID] && owned[p.PPID] {
				owned[p.PID] = true
				out = append(out, p)
				changed = true
			}
		}
	}
	return out
}
func isDescendant(child, parent int) bool {
	for n := 0; n < 1024 && child > 1; n++ {
		p, e := proc(child)
		if e != nil {
			return false
		}
		if p.PPID == parent {
			return true
		}
		if p.PPID == child {
			return false
		}
		child = p.PPID
	}
	return false
}
func signalOwned(p Proc, parent int, sig syscall.Signal) error {
	// pidfd_open + pidfd_send_signal avoid a PID-reuse race. Both syscall numbers
	// are shared by Linux amd64 and arm64 (target kernel supports pidfd).
	fd, _, e := syscall.Syscall(434, uintptr(p.PID), 0, 0)
	if e != 0 {
		return e
	}
	defer syscall.Close(int(fd))
	if !sameProc(p) || !isDescendant(p.PID, parent) {
		return nil
	}
	_, _, e = syscall.Syscall6(424, fd, uintptr(sig), 0, 0, 0, 0)
	if e != 0 {
		return e
	}
	return nil
}
func stopChildren(parent int, grace time.Duration) error {
	deadline := time.Now().Add(grace)
	for {
		children := descendants(parent)
		if len(children) == 0 {
			return nil
		}
		sig := syscall.SIGTERM
		if time.Now().After(deadline) {
			sig = syscall.SIGKILL
		}
		for i := len(children) - 1; i >= 0; i-- {
			e := signalOwned(children[i], parent, sig)
			if e != nil && e != syscall.ESRCH {
				fmt.Fprintln(os.Stderr, "nodebaby: scoped stop:", e)
			}
		}
		// Reap adopted double-fork descendants as a subreaper. Service uses StartProcess
		// and Wait4 throughout, so there is no competing exec.Cmd.Wait goroutine.
		for {
			var st syscall.WaitStatus
			pid, _ := syscall.Wait4(-1, &st, syscall.WNOHANG, nil)
			if pid <= 0 {
				break
			}
		}
		if time.Now().After(deadline.Add(2 * time.Second)) {
			return errors.New("children remain; host cgroup teardown required")
		}
		time.Sleep(50 * time.Millisecond)
	}
}
func loadState(l Layout) (State, error) {
	var s State
	b, e := os.ReadFile(filepath.Join(l.Data, "state.json"))
	if e == nil {
		e = json.Unmarshal(b, &s)
	}
	return s, e
}
func bootID() string {
	b, _ := os.ReadFile("/proc/sys/kernel/random/boot_id")
	return strings.TrimSpace(string(b))
}
func stateLive(s State) bool {
	return s.BootID != "" && s.BootID == bootID() && s.Controller.PID > 1 && s.Client.PID > 1 && sameProc(s.Controller) && sameProc(s.Client) && isDescendant(s.Client.PID, s.Controller.PID)
}
func portOwned(s State) bool {
	if !stateLive(s) {
		return false
	}
	inodes := map[string]bool{}
	for _, f := range []string{"/proc/net/tcp", "/proc/net/tcp6"} {
		b, _ := os.ReadFile(f)
		for _, line := range strings.Split(string(b), "\n") {
			fields := strings.Fields(line)
			if len(fields) < 10 || fields[3] != "0A" {
				continue
			}
			parts := strings.Split(fields[1], ":")
			if len(parts) != 2 {
				continue
			}
			p, _ := strconv.ParseInt(parts[1], 16, 32)
			if int(p) == s.Port {
				inodes["socket:["+fields[9]+"]"] = true
			}
		}
	}
	for _, p := range descendants(s.Controller.PID) {
		entries, _ := os.ReadDir(fmt.Sprintf("/proc/%d/fd", p.PID))
		for _, f := range entries {
			link, _ := os.Readlink(fmt.Sprintf("/proc/%d/fd/%s", p.PID, f.Name()))
			if inodes[link] {
				return true
			}
		}
	}
	return false
}
func processStatus(l Layout) Status {
	result := Status{Version: version, ClientVersion: "4.3.5-731", Port: 9118, Note: "进程状态不代表已绑定或组网成功；本版本尚未实机验证。"}
	if cfg, e := loadSettings(l.Config); e == nil {
		result.Port = cfg.Port
	}
	if s, e := loadState(l); e == nil && stateLive(s) {
		result.Running = true
		result.Port = s.Port
		result.Started = s.Started
		result.Ready = portOwned(s)
	}
	return result
}
func bindingURL(location string) (string, error) {
	u, e := url.Parse(location)
	if e != nil || u.Scheme != "https" || u.User != nil || u.Port() != "" || u.Path != "/istore/" || len(location) > 8192 {
		return "", errors.New("unrecognized official binding URL")
	}
	for _, host := range []string{"iepose.com", "www.iepose.com", "ionewu.com", "www.ionewu.com", "onewu.cn", "www.onewu.cn", "onewu.net", "www.onewu.net"} {
		if strings.EqualFold(u.Hostname(), host) {
			return u.String(), nil
		}
	}
	return "", errors.New("binding URL host is outside the official allowlist")
}
func binding(l Layout) (any, error) {
	s, e := loadState(l)
	if e != nil || !portOwned(s) {
		return nil, errors.New("client does not own a ready binding listener")
	}
	// Never follow the redirect or use environment proxies; URL may contain a binding secret.
	transport := &http.Transport{Proxy: nil, DialContext: (&net.Dialer{Timeout: time.Second}).DialContext, DisableKeepAlives: true, MaxResponseHeaderBytes: 16384}
	defer transport.CloseIdleConnections()
	client := &http.Client{Transport: transport, Timeout: 2 * time.Second, CheckRedirect: func(*http.Request, []*http.Request) error { return http.ErrUseLastResponse }}
	r, e := client.Get(fmt.Sprintf("http://127.0.0.1:%d/", s.Port))
	if e != nil {
		return nil, errors.New("binding listener not ready")
	}
	defer r.Body.Close()
	if r.StatusCode < 300 || r.StatusCode > 399 {
		return nil, errors.New("client has not returned a binding redirect")
	}
	link, e := bindingURL(r.Header.Get("Location"))
	if e != nil {
		return nil, e
	}
	return map[string]any{"url": link, "bound": "unknown"}, nil
}

// Keep only bounded vendor output, private to this extension. It is deliberately
// absent from the UI/API because upstream output may contain device credentials.
type cappedLog struct {
	file *os.File
	size int64
}

func (w *cappedLog) Write(b []byte) (int, error) {
	n := len(b)
	if w.size+int64(n) > 1<<20 {
		if e := w.file.Truncate(0); e != nil {
			return 0, e
		}
		if _, e := w.file.Seek(0, 0); e != nil {
			return 0, e
		}
		w.size = 0
	}
	if len(b) > 1<<20 {
		b = b[len(b)-(1<<20):]
	}
	_, e := w.file.Write(b)
	w.size += int64(len(b))
	return n, e
}
func event(l Layout, text string) {
	_ = atomicJSON(filepath.Join(l.Data, "last-event.json"), map[string]string{"time": time.Now().UTC().Format(time.RFC3339), "message": text})
}

func runOnce(ctx context.Context, l Layout) (result error) {
	cfg, e := loadSettings(l.Config)
	if e != nil {
		return e
	}
	if !cfg.ServiceEnabled {
		return errors.New("service is disabled")
	}
	if e = verifyPayload(l); e != nil {
		return e
	}
	runtimeDir, e := materialize(l)
	if e != nil {
		return e
	}
	store := filepath.Join(l.Data, "store")
	tmp := filepath.Join(l.Data, "tmp")
	for _, p := range []string{store, tmp} {
		if e = privateDir(p); e != nil {
			return e
		}
	}
	listener, e := net.Listen("tcp", fmt.Sprintf("0.0.0.0:%d", cfg.Port))
	if e != nil {
		return errors.New("binding port is in use")
	}
	listener.Close()
	logFile, e := os.OpenFile(filepath.Join(l.Data, "vendor-output.log"), os.O_CREATE|os.O_WRONLY|os.O_TRUNC, 0600)
	if e != nil {
		return e
	}
	defer logFile.Close()
	logWriter := &cappedLog{file: logFile}
	r, w, e := os.Pipe()
	if e != nil {
		return e
	}
	defer r.Close()
	logDone := make(chan struct{})
	go func() { _, _ = io.Copy(logWriter, r); close(logDone) }()
	command := filepath.Join(runtimeDir, "bin/owjdxb")
	args := []string{command, "-s", fmt.Sprintf("--port=%d", cfg.Port), "--store=" + store, "--tmpfspath=" + tmp}
	env := append(os.Environ(), "OWAPP_STORE_PATH="+store, "TMPDIR="+tmp, "HOME="+l.Data)
	null, e := os.Open("/dev/null")
	if e != nil {
		w.Close()
		return e
	}
	defer null.Close()
	if e = ctx.Err(); e != nil {
		w.Close()
		return e
	}
	child, e := os.StartProcess(command, args, &os.ProcAttr{Dir: runtimeDir, Env: env, Files: []*os.File{null, w, w}, Sys: &syscall.SysProcAttr{Setpgid: true}})
	w.Close()
	if e != nil {
		return e
	}
	defer child.Release()
	self, _ := proc(os.Getpid())
	mainProc, e := proc(child.Pid)
	if e != nil {
		_ = stopChildren(os.Getpid(), time.Second)
		return errors.New("client exited before startup")
	}
	state := State{bootID(), self, mainProc, cfg.Port, time.Now().UTC().Format(time.RFC3339)}
	defer func() {
		if cleanupErr := stopChildren(os.Getpid(), 2*time.Second); cleanupErr != nil {
			result = fmt.Errorf("%w: %v", errUnreaped, cleanupErr)
		}
		r.Close()
		<-logDone
		os.Remove(filepath.Join(l.Data, "state.json"))
		event(l, "客户端进程已停止；宿主负责最终 cgroup 清理。")
	}()
	if e = atomicJSON(filepath.Join(l.Data, "state.json"), state); e != nil {
		return e
	}
	event(l, "已启动客户端进程；绑定与组网状态尚未确认。")
	// The main process must remain in foreground; a clean early exit also fails.
	ticker := time.NewTicker(200 * time.Millisecond)
	defer ticker.Stop()
	for {
		select {
		case <-ctx.Done():
			return nil
		case <-ticker.C:
			var status syscall.WaitStatus
			pid, err := syscall.Wait4(child.Pid, &status, syscall.WNOHANG, nil)
			if err != nil {
				return err
			}
			if pid == child.Pid {
				return fmt.Errorf("foreground client exited: %v", status)
			}
		}
	}
}
func printJSON(v any) error { return json.NewEncoder(os.Stdout).Encode(v) }
func main() {
	l, e := layout()
	if e != nil {
		fmt.Fprintln(os.Stderr, e)
		os.Exit(78)
	}
	command := "--service"
	if len(os.Args) == 2 {
		command = os.Args[1]
	} else if len(os.Args) > 2 {
		fmt.Fprintln(os.Stderr, "one command expected")
		os.Exit(64)
	}
	switch command {
	case "status":
		e = printJSON(getStatus(l))
	case "binding":
		var value any
		value, e = binding(l)
		if e == nil {
			e = printJSON(value)
		}
	case "logs":
		logs, logErr := requestLogs(l)
		if logErr != nil {
			logs = readLogs(l)
		}
		e = printJSON(logs)
	case "restart":
		var response any
		response, e = requestRestart(l)
		if e == nil {
			e = printJSON(response)
		}
	case "--health":
		var cfg Settings
		cfg, e = loadSettings(l.Config)
		if e == nil {
			e = verifyRuntime(l)
		}
		if e == nil && cfg.ServiceEnabled && !getStatus(l).Running {
			e = errors.New("client is not running")
		}
	case "--service":
		var cfg Settings
		cfg, e = loadSettings(l.Config)
		if e == nil {
			e = verifyRuntime(l)
		}
		if e != nil {
			fmt.Fprintln(os.Stderr, "nodebaby:", e)
			os.Exit(78)
		}
		if !cfg.ServiceEnabled {
			os.Exit(78)
		}
		ctx, cancel := signal.NotifyContext(context.Background(), syscall.SIGTERM, syscall.SIGINT)
		defer cancel()
		e = service(ctx, l)
	default:
		e = errors.New("unknown command")
	}
	if e != nil {
		fmt.Fprintln(os.Stderr, "nodebaby:", e)
		os.Exit(1)
	}
}
